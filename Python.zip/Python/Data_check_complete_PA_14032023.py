# -*- coding: utf-8 -*-
"""
Created on Tue Mar 14 09:41:28 2023

@author: A3525
"""

#%%

import pandas as pd
import numpy as np

#%% DrFirst data

DrFirst_df = pd.read_excel(r"D:/DrFirst/DrFirst_Data/DrFirst_Combined_Data_3M_2022_09_10_11.xlsx")
DrFirst_df.shape # (13967, 17)
DrFirst_df.columns

DrFirst_pats = DrFirst_df[['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
       'quantity', 'refills_available']]
DrFirst_pats.patient_id_encoded.nunique() # 12461

#%% LAAD

# Rx Fact
Rx_Fact = pd.read_pickle(r"D:/DrFirst/LAAD_Data/Rx_Fact_3M_Sep22_Nov22.pkl")

Rx_Fact.shape # (10151266, 19)
list(Rx_Fact.columns)
Rx_fact_v2 = Rx_Fact[['claim_id', 'patient_id', 'rx_dt', 'wrt_dt', 'claim_type', 'quantity', 'provider_id', 'product','ims_id']]
Rx_fact_v2.patient_id.str.len().unique() # [10, 11,  9,  7,  6,  8,  5]

# Dim_patient
Dim_Pat = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_patient.pkl")
Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.columns # ['patient_id', 'patient_birth_year', 'patient_gender']
Dim_Pat.patient_id.astype(str).str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

# Merging Rx_Fact and Dim_pat
Rx_fact_v2.shape # (10151266, 8)
Rx_pat_demo = Rx_fact_v2.merge(Dim_Pat, how='left', on='patient_id')
Rx_pat_demo.shape # (10151266, 10)
Rx_pat_demo.isna().sum()

# Dim_Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")
Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']

# Merging Dim_Provider with Rx_fact
Rx_pat_demo.provider_id.astype(str).str.len().unique() # [ 9, 10,  3,  8,  7,  6]
Dim_Provider.provider_id.astype(str).str.len().unique() # [ 6,  7,  8,  9,  3,  4,  5, 10]

Rx_pat_demo.provider_id
Dim_Provider.provider_id

Rx_pat_demo['provider_id'] = Rx_pat_demo['provider_id'].astype(str)
Dim_Provider['provider_id'] = Dim_Provider['provider_id'].astype(str)

Rx_master = Rx_pat_demo.merge(Dim_Provider, how='left', on='provider_id')
Rx_master.shape # (10151266, 11)

Rx_master.isna().sum()
Rx_master.columns

#%% checking mapping

DrFirst_pats.columns
Rx_master.rename(columns={'npi_number':'npi'}, inplace = True)
Rx_master.npi.str.len().unique() # [10., nan]
DrFirst_pats.npi.astype(str).str.len().unique() # [10]
DrFirst_pats['npi'] = DrFirst_pats['npi'].astype(str)
DrFirst_pats.npi.str.len().unique() # [10]

Dr_First_map_check = DrFirst_pats.merge(Rx_master, how='left', on='npi')
Dr_First_map_check.shape # (2412953, 18)
Dr_First_map_check.columns
# ['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
#        'quantity_x', 'refills_available', 'claim_id', 'patient_id', 'rx_dt',
#        'claim_type', 'quantity_y', 'provider_id', 'product', 'ims_id',
#        'patient_birth_year', 'patient_gender']
Dr_First_map_check.isna().sum()

Dr_First_map_check.gender.unique() # ['F', 'M', 'U', nan]
Dr_First_map_check.patient_gender.unique() # ['F', 'M', 'U', None, nan]
Dr_First_map_check.rx_date # format 2022-11-21
Dr_First_map_check.wrt_dt # format 2022-08-08
Dr_First_map_check.quantity_x # 60
Dr_First_map_check.quantity_y # 60.0
Dr_First_map_check['quantity_x'] = Dr_First_map_check.quantity_x.astype(float)
Dr_First_map_check["age"] = 2022-Dr_First_map_check["patient_birth_year"]
Dr_First_map_check["age_buc"] =np.where((Dr_First_map_check["age"]>=18) & (Dr_First_map_check["age"]<31), "18-30",
                                        np.where((Dr_First_map_check["age"]>=31) & (Dr_First_map_check["age"]<41), "31-40",
                                                 np.where((Dr_First_map_check["age"]>=41) & (Dr_First_map_check["age"]<51), "41-50",
                                                          np.where((Dr_First_map_check["age"]>=51) & (Dr_First_map_check["age"]<61), "51-60",
                                                                   np.where((Dr_First_map_check["age"]>=61) & (Dr_First_map_check["age"]<71), "61-70",
                                                                            np.where((Dr_First_map_check["age"]>=71) & (Dr_First_map_check["age"]<81), "71-80", "81+"))))))

Dr_First_map_check_v2 = Dr_First_map_check.loc[(Dr_First_map_check['gender']==Dr_First_map_check['patient_gender']) &
                                               (Dr_First_map_check['rx_date']==Dr_First_map_check['wrt_dt']) &
                                               (Dr_First_map_check['quantity_x']==Dr_First_map_check['quantity_y']) &
                                               (Dr_First_map_check['age_bucket']==Dr_First_map_check['age_buc']),
                                               :]

Dr_First_map_check_v2.shape # (10197, 20)

Dr_First_map_check_v2.to_clipboard()
Dr_First_map_check_v2.to_excel(r"D:\DrFirst\Output\mapping_check_with_wrt_dt.xlsx", index = False)
Dr_First_map_check_v2.claim_id

Rx_Fact['rx_date_check']=Rx_Fact['rx_dt']-Rx_Fact['wrt_dt']

Rx_Fact_1check = Rx_Fact.loc[Rx_Fact['rx_date_check'] < 0]

Rx_Fact['rx_date_check'] = Rx_Fact['rx_date_check'].dt.days

Rx_Fact_1check = Rx_Fact.loc[Rx_Fact['rx_date_check'] < 0]
