# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 04:39:15 2023

@author: rakesh.vashist
"""

import pandas as pd
import numpy as np

#%% DrFirst data

DrFirst_df = pd.read_excel(r"D:/DrFirst/DrFirst_Data/DrFirst_Combined_Data_4M_2022_09_to_12.xlsx")
DrFirst_df.shape # (18927, 17)
DrFirst_df.columns
DrFirst_df.dtypes

DrFirst_pats = DrFirst_df[['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
       'quantity', 'refills_available']]
DrFirst_pats.patient_id_encoded.nunique() # 16179
DrFirst_pats[['patient_id_encoded', 'rx_date']].drop_duplicates().shape # (18927, 2)

#%% LAAD

# Rx Fact
Rx_Fact = pd.read_pickle(r"D:/DrFirst/LAAD_Data/Rx_Fact_10M_2022_03_12.pkl")

Rx_Fact.shape # (11595242, 35)
list(Rx_Fact.columns)
Rx_Fact.wrt_dt.min() # 2022-05-01
Rx_Fact.wrt_dt.max() # 2022-12-31
Rx_Fact.rx_dt.min() # 2022-04-25
Rx_Fact.rx_dt.max() # 2022-12-31

# Checking where rx_dt < wrt_dt
Rx_Fact.loc[Rx_Fact['rx_dt']<Rx_Fact['wrt_dt'], :].shape # (1846, 35)

pat_id_Rx_before_wrt = Rx_Fact.loc[Rx_Fact['rx_dt']<Rx_Fact['wrt_dt'],'patient_id'].unique()
len(pat_id_Rx_before_wrt) # 1580
pat_id_with_no_wrt_dt = Rx_Fact.loc[Rx_Fact['wrt_dt'].isna(),'patient_id'].unique()
len(pat_id_with_no_wrt_dt) # 0


Rx_fact_v2 = Rx_Fact.loc[Rx_Fact['patient_id']>=Rx_Fact['wrt_dt'], 
                         ['claim_id', 'patient_id', 'wrt_dt', 'claim_type', 'quantity', 'provider_id', 'product','ims_id']]
Rx_fact_v2.patient_id.str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Rx_fact_v2.shape # (11593396, 8)

# Dim_patient
Dim_Pat = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_patient.pkl")
Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.columns # ['patient_id', 'patient_birth_year', 'patient_gender']
Dim_Pat.patient_id.astype(str).str.len().unique() # [10,  9,  8, 11,  7,  6,  5,  4]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

# Merging Rx_Fact and Dim_pat
Rx_fact_v2.shape # (11595242, 8)
Rx_pat_demo = Rx_fact_v2.merge(Dim_Pat, how='left', on='patient_id')
Rx_pat_demo.shape # (11595242, 10)
Rx_pat_demo.isna().sum()

Rx_pat_demo.patient_birth_year.min() # 0

# Dim_Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")
Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']
Dim_Provider.isna().sum() # 52375 npi_number NAs
Dim_Provider.provider_id.nunique() # 2624439

# Merging Dim_Provider with Rx_fact
Rx_pat_demo.provider_id.astype(str).str.len().unique() # [ 9, 10,  3,  8,  7]
Dim_Provider.provider_id.astype(str).str.len().unique() # [ 6,  7,  8,  9,  3,  4,  5, 10]

Rx_pat_demo.provider_id # format 7626100.0
Dim_Provider.provider_id # format 29777901.0

Rx_pat_demo['provider_id'] = Rx_pat_demo['provider_id'].astype(str)
Dim_Provider['provider_id'] = Dim_Provider['provider_id'].astype(str)

Rx_master = Rx_pat_demo.merge(Dim_Provider, how='left', on='provider_id')
Rx_master.shape # (11595242, 11)

Rx_master.isna().sum() # 117841 npi null
Rx_master.columns
Rx_master.ims_id.str.len().unique() # [ 7., nan]

# IC_Demo
ic_demo = pd.read_pickle(r'D:/DrFirst/LAAD_Data/ic_demo.pkl')
ic_demo.columns
ic_demo.isna().sum() # 119028 npi_id null
ic_demo.shape # (2186736, 2)
ic_demo.IMS_ID.str.len().unique() # 7
ic_demo.rename(columns={'IMS_ID':'ims_id'}, inplace=True)
ic_demo.dropna(inplace = True)
ic_demo.shape # (2067708, 2)

# Merging Rx_master with IC_Demo
Rx_master.columns
Rx_master_v2 = Rx_master.merge(ic_demo, how='left', on='ims_id')
Rx_master_v2.shape # (11595242, 12)

Rx_master_v2.columns
Rx_master_v2.isna().sum()
Rx_master_v2['npi'] = np.where(Rx_master_v2['npi_number'].isna(), Rx_master_v2['NPI_ID'], Rx_master_v2['npi_number'])
Rx_master_v2.to_clipboard()
Rx_master_v2.drop(columns=["NPI_ID", "npi_number"], inplace=True)
Rx_master_v2.columns
Rx_master_v2.isna().sum() # 117841 npi null

#%% checking mapping

DrFirst_pats.columns
# Rx_master.rename(columns={'npi_number':'npi'}, inplace = True)
Rx_master_v2.npi.str.len().unique() # [10., nan]
DrFirst_pats.npi.astype(str).str.len().unique() # [10]
DrFirst_pats['npi'] = DrFirst_pats['npi'].astype(str)
DrFirst_pats.npi.str.len().unique() # [10]

Dr_First_map_check = DrFirst_pats.merge(Rx_master_v2, how='left', on='npi')
Dr_First_map_check.shape # (3452961, 18)
Dr_First_map_check.columns
# ['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
#        'quantity_x', 'refills_available', 'claim_id', 'patient_id', 'rx_dt',
#        'claim_type', 'quantity_y', 'provider_id', 'product', 'ims_id',
#        'patient_birth_year', 'patient_gender']
Dr_First_map_check.isna().sum()

Dr_First_map_check.gender.unique() # ['F', 'M', 'U', nan]
Dr_First_map_check.patient_gender.unique() # ['F', 'M', 'U', None, nan]
Dr_First_map_check.rx_date # format 2022-11-21
Dr_First_map_check.wrt_dt # format 2022-08-08
Dr_First_map_check.quantity_x # 60
Dr_First_map_check.quantity_y # 60.0
Dr_First_map_check['quantity_x'] = Dr_First_map_check.quantity_x.astype(float)
Dr_First_map_check["age"] = 2022-Dr_First_map_check["patient_birth_year"]
Dr_First_map_check["age_buc"] =np.where((Dr_First_map_check["age"]<18), "<18",
                                        np.where((Dr_First_map_check["age"]>=18) & (Dr_First_map_check["age"]<31), "18-30",
                                                 np.where((Dr_First_map_check["age"]>=31) & (Dr_First_map_check["age"]<41), "31-40",
                                                          np.where((Dr_First_map_check["age"]>=41) & (Dr_First_map_check["age"]<51), "41-50",
                                                                   np.where((Dr_First_map_check["age"]>=51) & (Dr_First_map_check["age"]<61), "51-60",
                                                                            np.where((Dr_First_map_check["age"]>=61) & (Dr_First_map_check["age"]<71), "61-70",
                                                                                     np.where((Dr_First_map_check["age"]>=71) & (Dr_First_map_check["age"]<81), "71-80", "81+")))))))

Dr_First_map_check_v2 = Dr_First_map_check.loc[(Dr_First_map_check['gender']==Dr_First_map_check['patient_gender']) &
                                               (Dr_First_map_check['rx_date']==Dr_First_map_check['wrt_dt']) &
                                               (Dr_First_map_check['quantity_x']==Dr_First_map_check['quantity_y']) &
                                               (Dr_First_map_check['age_bucket']==Dr_First_map_check['age_buc']) & 
                                               (Dr_First_map_check['age']<2022),   # for birth_year = 0
                                               :]

Dr_First_map_check_v2.shape # (13872, 20)

Dr_First_map_check_v2.to_clipboard()
Dr_First_map_check_v2.to_excel(r"D:\DrFirst\Output\mapping_check_v3.xlsx")
Dr_First_map_check_v2.claim_id
Dr_First_map_check_v2.wrt_dt.min()
