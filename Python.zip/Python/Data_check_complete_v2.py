# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 04:39:15 2023

@author: rakesh.vashist
"""

import pandas as pd

#%% LAAD

# RX Fact
Rx_Fact = pd.read_pickle(r"D:/DrFirst/LAAD_Data/Rx_Fact_6M_2022_07_12.pkl")

Rx_Fact.shape # (40365684, 46)
list(Rx_Fact.columns)

Rx_Fact.provider_id.astype(str).str.len().unique()

ic_Demo = pd.read_parquet(r"D:/CommercialAnalytics/Axtria/03-Salix/09-Scheduled Tasks/IC_DEMO_ZTT/05_IC_DEMO/XIF_IC_Q1_v2_DEMO_Q1_v1_2023_APP.parquet")
list(ic_Demo.columns)

ic_demo = ic_Demo[["NPI_ID", "IMS_ID"]]

# DrFirst Data
npi_df = pd.read_excel(r"D:/Rakesh/DrFirst/NPI_IDs.xlsx")
npi_df.shape # (3847, 1)
npi_df.npi.astype(str).str.len().unique() # 10
npi_df["npi"] = npi_df.npi.astype(str)
npi_df.npi.str.len().unique() # 10
ic_demo['NPI_ID'].str.len().unique() # 10

hcp_list = ic_demo.loc[ic_demo['NPI_ID'].isin(npi_df["npi"]),:]
hcp_list
Rx_Fact = Rx_Fact.loc[Rx_Fact['ims_id'].isin(hcp_list['IMS_ID']),:]
Rx_Fact.shape # (1620, 50)
Rx_Fact_v2 = Rx_Fact.loc[(Rx_Fact['rx_dt']>="2022-09-01") & (Rx_Fact['rx_dt']<="2022-09-30"),:]
Rx_Fact_v2.shape #  (66, 50)

con=psycopg2.connect(dbname='dwhdbprod02',
                     host='swapdbsdwhp02.csgzassu06ae.us-east-1.redshift.amazonaws.com', 
                     port='5439',
                     user='jzhu', 
                     password='9Ec6719fce069d18c51843bf6dd4feb3')

cur = con.cursor()
sql = '''
SELECT * FROM comm_stg.stg_laad_salix_patient_demographic
'''

pat_dim = pd.read_sql_query(sql, con)
list(pat_dim.columns)
pat_dim_v2 = pat_dim[['patient_id', 'patient_birth_year', 'patient_gender']]

Rx_Fact_v2.columns
Rx_Fact_v2.patient_id.str.len().unique() # [10, 11,  9,  8]
pat_dim.patient_id.astype(str).str.len().unique() # [ 9, 10,  8, 11,  7,  6,  5,  4]
pat_dim['patient_id'] = pat_dim['patient_id'].astype(str)

Rx_Fact_v3 = Rx_Fact_v2.merge(pat_dim, how='left', on='patient_id')

Rx_Fact_v3.to_pickle(r"D:\Rakesh\DrFirst\NPI_data.pkl")
Rx_Fact_v3.to_clipboard()




