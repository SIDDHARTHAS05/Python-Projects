# -*- coding: utf-8 -*-
"""
Created on Thu Mar  22 04:39:15 2023

@author: rakesh.vashist
"""

import pandas as pd
import numpy as np

#%% DrFirst data

DrFirst_df = pd.read_excel(r"D:/DrFirst/DrFirst_Data/DrFirst_Combined_Data_4M_2022_09_to_12.xlsx")
DrFirst_df.shape # (18927, 17)
DrFirst_df.columns
DrFirst_df.dtypes

# Data Cleaning
DrFirst_pats = DrFirst_df[['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
       'quantity', 'refills_available']]
DrFirst_pats.patient_id_encoded.nunique() # 16179
DrFirst_pats[['patient_id_encoded', 'rx_date']].drop_duplicates().shape # (18927, 2)

# Age Cleaning
multiple_age_check_v1 = DrFirst_pats[['patient_id_encoded', 'age_bucket']].drop_duplicates().groupby('patient_id_encoded').nunique().reset_index()
multiple_age_check_v2 = multiple_age_check_v1.loc[multiple_age_check_v1.age_bucket>1, :]
multiple_age_check_v2.shape # (41, 2)

multiple_age_patient_id = multiple_age_check_v2.patient_id_encoded.unique()

DrFirst_df_v2 = DrFirst_pats.loc[~DrFirst_pats['patient_id_encoded'].isin(multiple_age_patient_id), :]
DrFirst_df_v2.shape # (18823, 8)
DrFirst_df_v2.columns

# Gender Cleaning
multiple_gender_check_v1 = DrFirst_df_v2[['patient_id_encoded', 'gender']].drop_duplicates().groupby('patient_id_encoded').nunique().reset_index()
multiple_gender_check_v2 = multiple_gender_check_v1.loc[multiple_gender_check_v1.gender>1, :]
multiple_gender_check_v2.shape # (11, 2)

multiple_gender_patient_id = multiple_gender_check_v2.patient_id_encoded.unique()

DrFirst_df_v3 = DrFirst_df_v2.loc[~DrFirst_df_v2['patient_id_encoded'].isin(multiple_gender_patient_id), :]
DrFirst_df_v3.shape # (18791, 8)


#%% LAAD

# Rx Fact
Rx_Fact = pd.read_pickle(r"D:/DrFirst/LAAD_Data/Rx_Fact_10M_Mar22_Dec22_032023.pkl")

Rx_Fact.shape # (15341647, 37)
list(Rx_Fact.columns)
Rx_Fact.wrt_dt.min() # 2022-03-01
Rx_Fact.wrt_dt.max() # 2022-12-31
Rx_Fact.rx_dt.min() # 2022-02-28
Rx_Fact.rx_dt.max() # 2022-12-31

# mkt_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX','LACTULOSE']

# Rx_Fact = Rx_Fact.loc[Rx_Fact['product'].isin(mkt_products)]
# Rx_Fact.shape # (15314918, 37)

# Rx_Fact = Rx_Fact.loc[Rx_Fact['claim_status']!='I']
# Rx_Fact.shape # (12938458, 37)

Rx_Fact.wrt_dt.isna().sum() # 295008 wrt_dt NA
Rx_Fact.loc[Rx_Fact.rx_dt<Rx_Fact.wrt_dt, :].shape # (2450, 37)

wrt_dt_na_pats = Rx_Fact.loc[Rx_Fact.wrt_dt.isna(), 'patient_id'].unique()
len(wrt_dt_na_pats) # 136648
Rx_Fact_v2 = Rx_Fact.loc[~Rx_Fact.patient_id.isin(wrt_dt_na_pats), :]
Rx_Fact_v2.shape # (14922957, 37)

early_rx_pats = Rx_Fact_v2.loc[Rx_Fact_v2.rx_dt<Rx_Fact_v2.wrt_dt, 'patient_id'].unique()
len(early_rx_pats) # 2064
Rx_Fact_v2 = Rx_Fact_v2.loc[~Rx_Fact_v2.patient_id.isin(early_rx_pats), :]
Rx_Fact_v2.shape # (14916839, 37)

# Checking where rx_dt < wrt_dt
Rx_Fact_v2.loc[Rx_Fact['rx_dt']<Rx_Fact['wrt_dt'], :].shape #  (0, 37)
Rx_Fact_v2['wrt_dt'].isna().sum() # 0

req_columns = ['claim_id', 'patient_id', 'wrt_dt', 'claim_type', 'quantity', 'provider_id', 'product','ims_id']

Rx_Fact_v2.patient_id.str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Rx_Fact_v2.shape # (14916839, 37)

Rx_Fact_v2 = Rx_Fact_v2.loc[Rx_Fact_v2['product']=='XIF550', req_columns]
Rx_Fact_v2.shape # (984807, 8)

# Dim_patient
Dim_Pat = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_patient.pkl")
Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.columns # ['patient_id', 'patient_birth_year', 'patient_gender']
Dim_Pat.patient_id.astype(str).str.len().unique() # [10,  9,  8, 11,  7,  6,  5,  4]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

# Merging Rx_Fact and Dim_pat
Rx_Fact_v2.shape # (984807, 8)
Rx_pat_demo = Rx_Fact_v2.merge(Dim_Pat, how='left', on='patient_id')
Rx_pat_demo.shape # (984807, 10)
Rx_pat_demo.isna().sum()

Rx_pat_demo.patient_birth_year.min() # 0
Rx_pat_demo = Rx_pat_demo.loc[Rx_pat_demo['patient_birth_year']>0, :]
Rx_pat_demo.isna().sum() # Gender, age both 0
Rx_pat_demo.shape # (962834, 10)

# Dim_Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")
Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']
Dim_Provider.isna().sum() # 52375 npi_number NAs
Dim_Provider.provider_id.nunique() # 2624438
Dim_Provider.dropna(inplace=True)

# Merging Dim_Provider with Rx_fact
Rx_pat_demo.provider_id.astype(str).str.len().unique() # [ 9, 10,  3,  8,  7]
Dim_Provider.provider_id.astype(str).str.len().unique() # [ 6,  7,  8,  9,  3,  4,  5, 10]

Rx_pat_demo.provider_id # format 7626100.0
Dim_Provider.provider_id # format 29777901.0

Rx_pat_demo['provider_id'] = Rx_pat_demo['provider_id'].astype(str)
Dim_Provider['provider_id'] = Dim_Provider['provider_id'].astype(str)

Rx_master = Rx_pat_demo.merge(Dim_Provider, how='left', on='provider_id')
Rx_master.shape # (962834, 11)

Rx_master.isna().sum() # 9564 npi null
Rx_master.columns
Rx_master.ims_id.str.len().unique() # [ 7., nan]

# IC_Demo
ic_demo = pd.read_pickle(r'D:/DrFirst/LAAD_Data/ic_demo.pkl')
ic_demo.columns
ic_demo.isna().sum() # 119028 npi_id null
ic_demo.shape # (2186736, 2)
ic_demo.IMS_ID.str.len().unique() # 7
ic_demo.rename(columns={'IMS_ID':'ims_id'}, inplace=True)
ic_demo.dropna(inplace = True)
ic_demo.shape # (2067708, 2)

# Merging Rx_master with IC_Demo
Rx_master.columns
Rx_master_v2 = Rx_master.merge(ic_demo, how='left', on='ims_id')
Rx_master_v2.shape # (962834, 12)

Rx_master_v2.columns
Rx_master_v2.isna().sum()
Rx_master_v2['npi'] = np.where(Rx_master_v2['npi_number'].isna(), Rx_master_v2['NPI_ID'], Rx_master_v2['npi_number'])
Rx_master_v2.to_clipboard()
Rx_master_v2.drop(columns=["NPI_ID", "npi_number"], inplace=True)
Rx_master_v2.columns
Rx_master_v2.isna().sum() # 9564 npi null

#%% checking mapping

DrFirst_df_v3.columns
# Rx_master.rename(columns={'npi_number':'npi'}, inplace = True)
Rx_master_v2.npi.str.len().unique() # [10., nan]
DrFirst_df_v3.npi.astype(str).str.len().unique() # [10]
DrFirst_df_v3['npi'] = DrFirst_df_v3['npi'].astype(str)
DrFirst_df_v3.npi.str.len().unique() # [10]

Dr_First_map_check = DrFirst_df_v3.merge(Rx_master_v2, how='left', on='npi')
Dr_First_map_check.shape # (1188403, 18)
Dr_First_map_check.columns
# ['patient_id_encoded', 'npi', 'age_bucket', 'gender', 'state', 'rx_date',
#        'quantity_x', 'refills_available', 'claim_id', 'patient_id', 'rx_dt',
#        'claim_type', 'quantity_y', 'provider_id', 'product', 'ims_id',
#        'patient_birth_year', 'patient_gender']
Dr_First_map_check.isna().sum()

Dr_First_map_check.gender.unique() # ['F', 'M', 'U', nan]
Dr_First_map_check.patient_gender.unique() # ['F', 'M', 'U', nan]
Dr_First_map_check.rx_date # format 2022-11-21
Dr_First_map_check.wrt_dt # format 2022-08-08
Dr_First_map_check.quantity_x # 60
Dr_First_map_check.quantity_y # 60.0
Dr_First_map_check['quantity_x'] = Dr_First_map_check.quantity_x.astype(float)
Dr_First_map_check["age"] = 2022-Dr_First_map_check["patient_birth_year"]
Dr_First_map_check["age_buc"] =np.where((Dr_First_map_check["age"]<18), "<18",
                                        np.where((Dr_First_map_check["age"]>=18) & (Dr_First_map_check["age"]<31), "18-30",
                                                 np.where((Dr_First_map_check["age"]>=31) & (Dr_First_map_check["age"]<41), "31-40",
                                                          np.where((Dr_First_map_check["age"]>=41) & (Dr_First_map_check["age"]<51), "41-50",
                                                                   np.where((Dr_First_map_check["age"]>=51) & (Dr_First_map_check["age"]<61), "51-60",
                                                                            np.where((Dr_First_map_check["age"]>=61) & (Dr_First_map_check["age"]<71), "61-70",
                                                                                     np.where((Dr_First_map_check["age"]>=71) & (Dr_First_map_check["age"]<81), "71-80", "81+")))))))

Dr_First_map_check_v2 = Dr_First_map_check.loc[(Dr_First_map_check['gender']==Dr_First_map_check['patient_gender']) &
                                               (Dr_First_map_check['rx_date']==Dr_First_map_check['wrt_dt']) &
                                               (Dr_First_map_check['quantity_x']==Dr_First_map_check['quantity_y']) &
                                               (Dr_First_map_check['age_bucket']==Dr_First_map_check['age_buc']) & 
                                               (Dr_First_map_check['age']<2022),   # for birth_year = 0
                                               :]

Dr_First_map_check_v2.shape # (13354, 20)

Dr_First_map_check_v2.to_clipboard()
Dr_First_map_check_v2.to_excel(r"D:\DrFirst\Output\mapping_check_RV_v6_0328.xlsx")
Dr_First_map_check_v2.claim_id.nunique() # 13043
Dr_First_map_check_v2.shape # 9825
Dr_First_map_check_v2.wrt_dt.min() # (13354, 20)
Dr_First_map_check_v2.columns
Dr_First_map_check_v2.shape # (13354, 20)


# Ensuring 1-1 claims mapping
# Dr_First_map_check_v2[['patient_id_encoded', 'rx_date', 'claim_id']].drop_duplicates().shape # (13354, 3)
# Dr_First_map_check_v2[['patient_id_encoded', 'rx_date']].drop_duplicates().shape # (8366, 2)

# dup_claims_df = Dr_First_map_check_v2[['patient_id_encoded', 'claim_id']].groupby('claim_id').count().reset_index()
# dup_claims_df.rename(columns={'patient_id_encoded':'n_claims'}, inplace=True)
# dup_claims_id = dup_claims_df.loc[dup_claims_df.n_claims>1, 'claim_id']

# Dr_First_map_check_v3 = Dr_First_map_check_v2.loc[~Dr_First_map_check_v2.claim_id.isin(dup_claims_id), :]
# Dr_First_map_check_v3.shape # (12761, 20)

# Dr_First_map_check_v3[['patient_id_encoded', 'rx_date']].isna().sum().sum() # 0
# Dr_First_map_check_v3[['patient_id_encoded', 'rx_date']].dtypes

# Dr_First_map_check_v4 = Dr_First_map_check_v3.copy()
# Dr_First_map_check_v4['d_key'] = Dr_First_map_check_v3['patient_id_encoded'].astype(str) + "_" + Dr_First_map_check_v3['rx_date'].astype(str)
# dup_dkey_df = Dr_First_map_check_v4[['patient_id_encoded', 'd_key']].groupby('d_key').count().reset_index()
# dup_dkey_df.rename(columns={'patient_id_encoded':'n_dkey'}, inplace=True)
# dup_d_key = dup_dkey_df.loc[dup_dkey_df.n_dkey>1, 'd_key']

# Dr_First_map_check_v5 = Dr_First_map_check_v4.loc[~Dr_First_map_check_v4.d_key.isin(dup_d_key), :]
# Dr_First_map_check_v5.shape # (4938, 21)
# Dr_First_map_check_v5.columns

# Ensuring 1-1 patient map
# Dr_First_map_check_v5 = Dr_First_map_check_v2.copy()
# Dr_First_map_check_v6 = Dr_First_map_check_v5[['patient_id_encoded', 
#                                                'patient_id']].groupby('patient_id_encoded').nunique().reset_index()
# patient_id_encoded_dup_list = Dr_First_map_check_v6.loc[Dr_First_map_check_v6['patient_id']>1, 'patient_id_encoded']

# Dr_First_map_check_v7 = Dr_First_map_check_v5.loc[~Dr_First_map_check_v5['patient_id_encoded'].isin(patient_id_encoded_dup_list), :]
# Dr_First_map_check_v7.shape # (12226, 20)

# Dr_First_map_check_v8 = Dr_First_map_check_v7[['patient_id_encoded', 
#                                                'patient_id']].groupby('patient_id').nunique().reset_index()
# patient_id_dup_list = Dr_First_map_check_v8.loc[Dr_First_map_check_v8['patient_id_encoded']>1, 'patient_id'].shape

# Dr_First_map_check_v9 = Dr_First_map_check_v7.loc[~Dr_First_map_check_v7['patient_id'].isin(patient_id_dup_list), :]
# Dr_First_map_check_v9.shape # (12226, 20)

# Dr_First_map_check_v9.patient_id.nunique() # 7383
