# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 05:53:28 2023

@author: ashish.ubana
"""


# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 08:12:58 2023

@author: anuj.singh
"""


#%% 1 - Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime
import psycopg2

os.chdir(r'D:\CommercialAnalytics\Axtria\03-Salix\05-Marketing Analytics\01 - Xifaxan\Xifaxan NPP Campaign Analytics 2022\Data Review\Campaign\Dr. First\3. Processed Data')

#%% 2 - User Inputs
min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)
max_date_10m = datetime(2022, 12, 31)
# ibsd_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX']
# he_products = ['XIF550', 'LACTULOSE']
mkt_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX','LACTULOSE']

#%% 3 - Input Files
# Rx_Fact table (LAAD Claims)
Rx_Fact = pd.read_pickle(r'Rx_Fact_10M_Mar22_Dec22_032023.pkl')
Rx_Fact.shape # (15341647, 36)
Rx_Fact.wrt_dt.min() # 2022-03-01
Rx_Fact.wrt_dt.max() # 2022-12-31
Rx_Fact.rx_dt.min() # 2022-02-28
Rx_Fact.rx_dt.max() # 2022-12-31

Rx_Fact = Rx_Fact.loc[Rx_Fact['product'].isin(mkt_products)]
Rx_Fact.shape # (15314918, 37)

Rx_Fact = Rx_Fact.loc[Rx_Fact['claim_status']!='I']
Rx_Fact.shape # (12938458, 37)

Rx_Fact.isna().sum() # 294625 wrt_dt NA
Rx_Fact.loc[Rx_Fact.rx_dt<Rx_Fact.wrt_dt, :].shape # (1242, 37)
wrt_dt_na_pats = Rx_Fact.loc[Rx_Fact.wrt_dt.isna(), 'patient_id'].unique()
len(wrt_dt_na_pats) # 136493
Rx_Fact_v2 = Rx_Fact.loc[~Rx_Fact.patient_id.isin(wrt_dt_na_pats), :]
Rx_Fact_v2.shape # (12545772, 37)

early_rx_pats = Rx_Fact_v2.loc[Rx_Fact_v2.rx_dt<Rx_Fact_v2.wrt_dt, 'patient_id'].unique()
len(early_rx_pats) # 1186
Rx_Fact_v2 = Rx_Fact_v2.loc[~Rx_Fact_v2.patient_id.isin(early_rx_pats), :]
Rx_Fact_v2.shape # (12543407, 37)

# Dim Patient
Dim_Pat = pd.read_pickle(r"dim_patient.pkl")
Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.isna().sum()
Dim_Pat.dropna(inplace=True)
Dim_Pat.shape
Dim_Pat.patient_birth_year.min() # 0
Dim_Pat = Dim_Pat.loc[Dim_Pat.patient_birth_year>0, :]
Dim_Pat.dtypes
Dim_Pat.patient_id.astype(str).str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

# Dim Provider
Dim_Provider = pd.read_pickle(r"dim_provider.pkl")
Dim_Provider.shape # (2624439, 2)
Dim_Provider.isna().sum()
# provider_id        1
# npi_number     52375
Dim_Provider.dropna(inplace=True)
Dim_Provider.columns # ['provider_id', 'npi_number']

#%% Claims Data Processing - Age, Gender, Indication
# Rx_Fact = Rx_Fact.loc[(Rx_Fact['new_wrt_dt'] >= min_date) & (Rx_Fact['new_wrt_dt'] <= max_date)]
# Rx_pat_demo = Rx_Fact.merge(Dim_Pat, how='left', on='patient_id')
# # Age
# Rx_pat_demo['age'] = 2022 - Rx_pat_demo['patient_birth_year']
# Rx_pat_demo['time_to_fill'] = Rx_pat_demo['rx_dt']-Rx_pat_demo['new_wrt_dt']
# Rx_pat_demo['time_to_fill'] = Rx_pat_demo['time_to_fill']/np.timedelta64(1, 'D')
# Rx_pat_demo.head().to_clipboard()
# df1 = pd.DataFrame(Rx_pat_demo.groupby(['patient_id', 'age', 'patient_gender', 
#                                         'claim_type', 'final_category']).agg(fills = ('patient_id', 'count'), 
#                                                                              avg_time_to_fill = ('time_to_fill', np.mean))).reset_index()

#%% 4 - Claims Data Processing - Age, Gender, Indication
Rx_pat_demo = Rx_Fact_v2.merge(Dim_Pat, how='left', on='patient_id')
Rx_pat_demo.shape
# Age
Rx_pat_demo['age'] = 2022 - Rx_pat_demo['patient_birth_year']
Rx_pat_demo[['rx_dt','wrt_dt']].isna().values.any() # False
# a = Rx_pat_demo.loc[Rx_pat_demo.patient_birth_year.isna(), 'patient_id'].unique()
Rx_pat_demo.dropna(subset=['patient_birth_year', 'patient_gender'],how='all',inplace=True)

Rx_pat_demo['time_to_fill'] = Rx_pat_demo['rx_dt']-Rx_pat_demo['wrt_dt']
Rx_pat_demo.time_to_fill.isna().values.any() # False
# Rx_pat_demo.head().to_clipboard()

Rx_pat_demo['time_to_fill'] = Rx_pat_demo['time_to_fill']/np.timedelta64(1, 'D')
# Rx_pat_demo.head().to_clipboard()
# Rx_pat_demo.columns
Rx_pat_demo.payer_plan_id.str.len().unique() # 10

#Rx_pat_demo.loc[Rx_pat_demo.time_to_fill.isna(), 'patient_id'].nunique()

#Rx_pat_demo.loc[Rx_pat_demo.age.isna(), 'patient_id'].nunique()
# 432,192 out of total 6,241,973 total patients

#Age Bucket
Rx_pat_demo['age_buc'] = np.where((Rx_pat_demo['age']<18), "<18",
                                  np.where((Rx_pat_demo['age']>=18) & (Rx_pat_demo['age']<31), "18-30",
                                           np.where((Rx_pat_demo['age']>=31) & (Rx_pat_demo['age']<41), "31-40",
                                                    np.where((Rx_pat_demo['age']>=41) & (Rx_pat_demo['age']<51), "41-50",
                                                             np.where((Rx_pat_demo['age']>=51) & (Rx_pat_demo['age']<61), "51-60",
                                                                      np.where((Rx_pat_demo['age']>=61) & (Rx_pat_demo['age']<71), "61-70",
                                                                               np.where((Rx_pat_demo['age']>=71) & (Rx_pat_demo['age']<81), "71-80","81+")))))))
Rx_pat_demo.age_buc.unique()                                           

#%% 5 - Populating Payment_Type
payer_spine = pd.read_pickle(r"payerspine_ims_unv_bridge_dec_22.pkl")
payer_spine.shape # (50268, 24)
payer_spine.columns
payer_spine.isna().sum() # 0 beneficiary_type

payer_spine['payment_type']=np.where(payer_spine['beneficiary_type']=='Cash','Cash',
                                    np.where(((payer_spine['beneficiary_type']=='FFS Medicaid')|
                                              (payer_spine['beneficiary_type']=='Managed Medicaid')|
                                              (payer_spine['beneficiary_type']=='Special Needs')|
                                              (payer_spine['beneficiary_type']=='CHIP')),'Medicaid', np.where(((payer_spine['beneficiary_type']=='Commercial')|
                                                                                                              (payer_spine['beneficiary_type']=='Mix')|
                                                                                                              (payer_spine['beneficiary_type']=='Non-Benefit')|
                                                                                                              (payer_spine['beneficiary_type']=='Workers Comp')|
                                                                                                              (payer_spine['beneficiary_type']=='ADAP')),'Commercial', np.where(((payer_spine['beneficiary_type']=='Medicare')|
                                                                                                                                                                                (payer_spine['beneficiary_type']=='Elderly')),'Medicare Part-D', np.where((payer_spine['beneficiary_type']=='HIX'),'HIX',pd.NA)))))
payer_spine = payer_spine[['plan_number', 'payment_type']]
payer_spine.plan_number.str.len().unique() # 10
payer_spine.rename(columns={'plan_number': 'payer_plan_id'}, inplace=True)

Rx_pat_demo.shape # (12543407, 42)
Rx_Master_v1 = Rx_pat_demo.merge(payer_spine, how='left', on = 'payer_plan_id')
Rx_Master_v1.shape # (12543407, 43)
Rx_Master_v1.isna().sum() # 8882 payment type NA
Rx_Master_v1['payment_type'] = Rx_Master_v1['payment_type'].fillna(value='Not Found')
Rx_Master_v1.pt_category_he_ibsd.unique() # ['OTHER', 'IBSD', 'HE']

#%% 6 - Monthly Fills for each patient from Rx Fact

Rx_Master_v1.shape # (11680174, 43)

Rx_Master_v2 = Rx_Master_v1.copy()

Rx_Master_v2['rx_month'] = pd.to_datetime(Rx_Master_v2['rx_dt'].dt.year.astype(str)+'-'+
                                      Rx_Master_v2['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
Rx_Master_v2['rx_month'].unique()

# Rx_Fact_IBSD = Rx_Master_v2.loc[Rx_Master_v2['pt_category_he_ibsd']=='IBSD']
# Rx_Fact_HE = Rx_Master_v2.loc[Rx_Master_v2['pt_category_he_ibsd']=='HE']
# Rx_Fact_OTHER = Rx_Master_v2.loc[Rx_Master_v2['pt_category_he_ibsd']=='OTHER']

# Market Total Fills
mkt_fills = Rx_Master_v2.groupby(['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'rx_month']).size().reset_index(name='mkt_fills')
mkt_fills_t = mkt_fills.pivot(index=['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], columns='rx_month', values='mkt_fills')
mkt_fills_t = mkt_fills_t.reset_index()
mkt_fills_t.fillna(0, inplace = True)
mkt_fills_t.columns
mkt_fills_t.columns = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'MKT_T_10', 'MKT_T_09', 'MKT_T_08', 'MKT_T_07', 'MKT_T_06', 'MKT_T_05', 'MKT_T_04', 'MKT_T_03', 'MKT_T_02', 'MKT_T_01']
mkt_fills_t['MKT_T_6M_02'] = mkt_fills_t.loc[:,'MKT_T_10':'MKT_T_05'].sum(axis=1)
mkt_fills_t['MKT_T_4M_01'] = mkt_fills_t.loc[:,'MKT_T_04':'MKT_T_01'].sum(axis=1)
mkt_fills_t['MKT_T_10M_01'] = mkt_fills_t.loc[:,'MKT_T_10':'MKT_T_01'].sum(axis=1)
mkt_fills_t['MKT_T_10M_01'].sum() # 11680174.0

# Market New Fills
mkt_n_fills = Rx_Master_v2.loc[Rx_Master_v2['refill_code']==0].groupby(['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'rx_month']).size().reset_index(name='mkt_n_fills')
mkt_n_fills_t = mkt_n_fills.pivot(index=['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], columns='rx_month', values='mkt_n_fills')
mkt_n_fills_t = mkt_n_fills_t.reset_index()
mkt_n_fills_t.fillna(0, inplace = True)
mkt_n_fills_t.columns
mkt_n_fills_t.columns = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'MKT_N_10', 'MKT_N_09', 'MKT_N_08', 'MKT_N_07', 'MKT_N_06', 'MKT_N_05', 'MKT_N_04', 'MKT_N_03', 'MKT_N_02', 'MKT_N_01']
mkt_n_fills_t['MKT_N_6M_02'] = mkt_n_fills_t.loc[:,'MKT_N_10':'MKT_N_05'].sum(axis=1)
mkt_n_fills_t['MKT_N_4M_01'] = mkt_n_fills_t.loc[:,'MKT_N_04':'MKT_N_01'].sum(axis=1)
mkt_n_fills_t['MKT_N_10M_01'] = mkt_n_fills_t.loc[:,'MKT_N_10':'MKT_N_01'].sum(axis=1)
mkt_n_fills_t['MKT_N_10M_01'].sum() # 9036599.0

# brand Total Fills
brand_fills = Rx_Master_v2.loc[Rx_Master_v2['product'] == 'XIF550'].groupby(['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'rx_month']).size().reset_index(name='brand_t_fills')
brand_fills_t = brand_fills.pivot(index=['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], columns='rx_month', values='brand_t_fills')
brand_fills_t = brand_fills_t.reset_index()
brand_fills_t.fillna(0, inplace = True)
brand_fills_t.columns
brand_fills_t.columns = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'BRAND_T_10', 'BRAND_T_09', 'BRAND_T_08', 'BRAND_T_07', 'BRAND_T_06', 'BRAND_T_05', 'BRAND_T_04', 'BRAND_T_03', 'BRAND_T_02', 'BRAND_T_01']
brand_fills_t['BRAND_T_6M_02'] = brand_fills_t.loc[:,'BRAND_T_10':'BRAND_T_05'].sum(axis=1)
brand_fills_t['BRAND_T_4M_01'] = brand_fills_t.loc[:,'BRAND_T_04':'BRAND_T_01'].sum(axis=1)
brand_fills_t['BRAND_T_10M_01'] = brand_fills_t.loc[:,'BRAND_T_10':'BRAND_T_01'].sum(axis=1)
brand_fills_t['BRAND_T_10M_01'].sum() # 696544.0

# Brand New Fills
brand_n_fills = Rx_Master_v2.loc[(Rx_Master_v2['refill_code']==0) & (Rx_Master_v2['product']=='XIF550')].groupby(['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'rx_month']).size().reset_index(name='brand_n_fills')
brand_n_fills_t = brand_n_fills.pivot(index=['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], columns='rx_month', values='brand_n_fills')
brand_n_fills_t = brand_n_fills_t.reset_index()
brand_n_fills_t.fillna(0, inplace = True)
brand_n_fills_t.columns
brand_n_fills_t.columns = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type', 'BRAND_N_10', 'BRAND_N_09', 'BRAND_N_08', 'BRAND_N_07', 'BRAND_N_06', 'BRAND_N_05', 'BRAND_N_04', 'BRAND_N_03', 'BRAND_N_02', 'BRAND_N_01']
brand_n_fills_t['BRAND_N_6M_02'] = brand_n_fills_t.loc[:,'BRAND_N_10':'BRAND_N_05'].sum(axis=1)
brand_n_fills_t['BRAND_N_4M_01'] = brand_n_fills_t.loc[:,'BRAND_N_04':'BRAND_N_01'].sum(axis=1)
brand_n_fills_t['BRAND_N_10M_01'] = brand_n_fills_t.loc[:,'BRAND_N_10':'BRAND_N_01'].sum(axis=1)
brand_n_fills_t['BRAND_N_10M_01'].sum() # 505250.0

#%% 7 - Diagnosis Data Processing - One Dx date for each indication if available
# # Diagnosis Data
# con=psycopg2.connect(dbname='dwhdbprod02',
#                      host='swapdbsdwhp02.csgzassu06ae.us-east-1.redshift.amazonaws.com', 
#                      port='5439',
#                      user='kguru', 
#                      password='2831077691D256a3e0c1ef84da536a26')

# cur = con.cursor() 

# sql='''SELECT * FROM comm_stg.stg_laad_salix_diagnosis'''
# pd.read_sql_query(sql, con)
# # dec22 ending: 2022-12-31  2021-01-01
Rx_Master_v2.shape
pat_dx_dt = Rx_Master_v2[['patient_id', 'pt_category_he_ibsd', 'dx_dt']].drop_duplicates()
pat_dx_dt.shape # (6228759, 3)
# pat_dx_dt.loc[pat_dx_dt.dx_dt.isna()].groupby('pt_category_he_ibsd')['patient_id'].count()
# pt_category_he_ibsd
# OTHER    3,646,421
# Name: patient_id, dtype: int64

#%% 8 - Avg Time to fill

ttf_pre_ov = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] >= min_date) &
                                                    (Rx_Master_v2['rx_month'] <= max_date)].
                                   groupby(['patient_id', 'age', 'patient_gender',
                                            'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                   agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'pre_ov_avg_ttf','patient_id':'pre_ov_n'}).reset_index()

ttf_pre_nrx = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] >= min_date) & 
                                                    (Rx_Master_v2['rx_month'] <= max_date) &
                                                    (Rx_Master_v2['refill_code']==0)].
                                    groupby(['patient_id', 'age', 'patient_gender',
                                             'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                    agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'pre_nrx_avg_ttf','patient_id':'pre_nrx_n'}).reset_index()
                                 

ttf_pre_not_nrx = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] >= min_date) & 
                                                    (Rx_Master_v2['rx_month'] <= max_date) &
                                                    (Rx_Master_v2['refill_code']!=0)].
                                    groupby(['patient_id', 'age', 'patient_gender',
                                             'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                    agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'pre_non_nrx_avg_ttf','patient_id':'pre_non_nrx_n'}).reset_index()

ttf_post_ov = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] > max_date) &
                                                    (Rx_Master_v2['rx_month'] <= max_date_10m)].
                                   groupby(['patient_id', 'age', 'patient_gender',
                                            'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                   agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'post_ov_avg_ttf','patient_id':'post_ov_n'}).reset_index()


ttf_post_nrx = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] > max_date) & 
                                                    (Rx_Master_v2['rx_month'] <= max_date_10m) &
                                                    (Rx_Master_v2['refill_code']==0)].
                                    groupby(['patient_id', 'age', 'patient_gender',
                                             'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                    agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'post_nrx_avg_ttf','patient_id':'post_nrx_n'}).reset_index()
                                    

ttf_post_not_nrx = pd.DataFrame(Rx_Master_v2.loc[(Rx_Master_v2['rx_month'] > max_date) & 
                                                    (Rx_Master_v2['rx_month'] <= max_date_10m) &
                                                    (Rx_Master_v2['refill_code']!=0)].
                                    groupby(['patient_id', 'age', 'patient_gender',
                                             'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']).
                                    agg({'time_to_fill' : 'mean','patient_id' : 'count'})).rename(columns={'time_to_fill':'post_non_nrx_avg_ttf','patient_id':'post_non_nrx_n'}).reset_index()

#%% FOR TOM - ADD CODE FOR SPEC

'''
SPEC TO BE CHECKED AT PAT ID, PATIENT INDICATION, CLAIM_TYPE AND PAYMENT TYPE
LATEST SPEC TO BE SELECTED
USE IC_DEMO PLACED IN THE DR. FIRST FOLDER
'''

ic_demo = pd.read_parquet(r'D:\CommercialAnalytics\Axtria\03-Salix\05-Marketing Analytics\01 - Xifaxan\Xifaxan NPP Campaign Analytics 2022\Data Review\Campaign\Dr. First\1. Inputs\XIF_IC_Q1_v2_DEMO_Q1_v1_2023_APP.parquet')
ic_demo.shape
ic_demo=ic_demo[['NPI_ID','IMS_ID','SPEC','TRUE_SPEC','XIF_TGT']]

ic_demo['IMS_ID']=ic_demo['IMS_ID'].astype(float)
Rx_Master_v2['ims_id']=Rx_Master_v2['ims_id'].astype(float)

Rx_Master_v3 = Rx_Master_v2.merge(ic_demo, left_on='ims_id',right_on='IMS_ID',how='left')
Rx_Master_v3['SPEC_count'] = Rx_Master_v3.groupby(['patient_id','pt_category_he_ibsd','claim_type','payment_type'],as_index='False')['SPEC'].transform('nunique')

# Patients who have visited more than 1 HCP SPEC
R3 = Rx_Master_v3[Rx_Master_v3['SPEC_count']>1]
R3.shape # (1427717, 50)
del R3

# Flag indicating Patient has visited more than 1 HCP SPEC
Rx_Master_v3['More_than_One_SPEC'] = np.where(Rx_Master_v3['SPEC_count']>1,1,0)
Rx_Master_v3.More_than_One_SPEC.sum()
Rx_Master_v3.shape

# Taking only the rows with the most recent SPEC visit
Rx_Master_v4 = Rx_Master_v3.sort_values(by=['patient_id','pt_category_he_ibsd','claim_type','payment_type','rx_dt'],ascending=False)

# Taking most recent SPEC visit incudling post period
#Rx_Master_v4 = Rx_Master_v4.groupby(['patient_id','pt_category_he_ibsd','claim_type','payment_type'],as_index=False).first()

# Taking most recent SPEC visit based on pre-period visits only
Rx_Master_v4 = Rx_Master_v4[Rx_Master_v4['rx_dt'].le(max_date)].groupby(['patient_id','pt_category_he_ibsd','claim_type','payment_type'],as_index=False).first()
Rx_Master_v4.shape # (4642145, 51)

#%% FOR TOM - ADD CODE FOR WEIGHTED AVG. OF ALL XIF550 PAID CLAIMS WRITTEN BY HCPS VISITED BY EACH PATIENT

#Using previous table to only sum XIF550 Paid claims
Rx_Master_v3 = Rx_Master_v3[Rx_Master_v3['claim_type']=='PD']
Rx_Master_v3.shape
Rx_Master_v3 = Rx_Master_v3[Rx_Master_v3['prod']=='XIF550']
Rx_Master_v3.shape
Rx_Master_v3 = Rx_Master_v3[(Rx_Master_v3['rx_dt']>=min_date) &(Rx_Master_v3['rx_dt']<=max_date)]
Rx_Master_v3.shape

HCP_total_claims = Rx_Master_v3.groupby(['ims_id'])['patient_id'].count().reset_index()
HCP_total_claims.columns = ['ims_id', 'total_xif_claims']
HCP_total_claims.shape
pat_hcp_count = Rx_Master_v3.groupby(['patient_id', 'ims_id']).size().reset_index().rename(columns={0:'total_visits'})

pat_count = Rx_Master_v3.groupby(['patient_id']).size().reset_index().rename(columns={0:'total_pat_claims'})

pat_hcp_count_1 = pd.merge(pat_hcp_count, pat_count, on = 'patient_id', how = 'left')
pat_hcp_count_1 = pd.merge(pat_hcp_count_1, HCP_total_claims, on = 'ims_id', how = 'left')

pat_hcp_count_1['adjusted_claims'] = (pat_hcp_count_1['total_visits']/pat_hcp_count_1['total_pat_claims'])*pat_hcp_count_1['total_xif_claims']

pat_adj_claims_final = pat_hcp_count_1.groupby(['patient_id']).agg(adj_claim_count = ('adjusted_claims', np.sum)).reset_index()
pat_adj_claims_final.shape #(159312, 2)
# y=Rx_Master_v3.groupby(['patient_id','ims_id'],as_index=False)['quantity'].sum()
# y.columns=['patient_id','ims_id','HCP_quantity']
# Rx_Master_v3 = Rx_Master_v3.merge(y, left_on=['patient_id','ims_id'],right_on=['patient_id','ims_id'],how='left')

# x=y.groupby(['patient_id'],as_index=False)['HCP_quantity'].sum()
# x.columns= ['patient_id','patient_quantity']
# Rx_Master_v3 = Rx_Master_v3.merge(x, on=['patient_id'],how='left')

# # Weight of patient's HCPs' quantities based on their overall XIF550 Paid Claims
# Rx_Master_v3['HCP_percentage'] = Rx_Master_v3['HCP_quantity']/ Rx_Master_v3['patient_quantity']
# R3 = Rx_Master_v3[['patient_id','HCP_percentage']]

# #Merge Weights to final table
# Rx_Master_v4 = Rx_Master_v4.merge(R3, on='patient_id', how='left')
# Rx_Master_v4['HCP_percentage']= Rx_Master_v4['HCP_percentage'].fillna(0)

#%% Creating Deciles Rx_Fact_v2
# Creating month column
# Rx_Fact_v3 = Rx_Fact_v2
# Rx_Fact_v3['rx_month']=pd.to_datetime(Rx_Fact_v3['rx_dt'].dt.year.astype(str)+'-'+
#                                           Rx_Fact_v3['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
# len(Rx_Fact_v3['rx_month'].unique())

# # creating a rx column with value one for each record
# Rx_Fact_v3['rx']=1

# #Xifaxan  HCP X Claim Type X Patient CNT
# dx_xif_cnt = pd.DataFrame(Rx_Fact_v3.groupby(['patient_id','ims_id','claim_type','life_cycle_claim_yn',
#                                                       'rx_month','product','refill_code']).agg(count=('rx','count'))).reset_index()

# dx_xif_cnt['rx_PD_TOTAL']=dx_xif_cnt.loc[:,'count']

# dx_xif_cnt.loc[:,'nrx_PD_TOTAL']=0
# dx_xif_cnt.loc[((dx_xif_cnt['refill_code']==0)),'nrx_PD_TOTAL']=dx_xif_cnt.loc[(dx_xif_cnt['refill_code']==0),'count']
                                                                                           
# len(dx_xif_cnt['rx_month'].unique())

# claim_counnt = pd.DataFrame(dx_xif_cnt.groupby(['ims_id','rx_month','product']).agg(rx_PD_TOTAL=('rx_PD_TOTAL',np.sum),
#                                                                                      nrx_PD_TOTAL=('nrx_PD_TOTAL',np.sum))).reset_index()

# def decile(df, col):
#     df_decile = df.sort_values(by = col,ascending=False)
#     A = df[col].sum()
#     decile_cut = A/10
    
#     ##Prepare cumsum for decile
#     df_decile['CUMSUM'] = df_decile[col].cumsum()
    
#     ##Create Decile
#     df_decile[str(col)+'_decile'] = 10-(np.ceil(df_decile['CUMSUM']/decile_cut-0.000000001))+1
#     df_decile.loc[df_decile[col]==0,str(col)+'_decile']=0
    
#     return df_decile.drop(['CUMSUM'],axis='columns')


# # Market Deciles by Indication
# mkt_fills_ibsd = mkt_fills_t[mkt_fills_t['pt_category_he_ibsd']== 'IBSD']
# mkt_fills_he = mkt_fills_t[mkt_fills_t['pt_category_he_ibsd']== 'HE']
# mkt_fills_other = mkt_fills_t[mkt_fills_t['pt_category_he_ibsd']== 'OTHER']

# mkt_ibsd = decile(mkt_fills_ibsd, 'MKT_T_6M_02')
# mkt_he = decile(mkt_fills_he, 'MKT_T_6M_02')
# mkt_other = decile(mkt_fills_other, 'MKT_T_6M_02')

# mkt_fills = pd.concat([mkt_ibsd, mkt_he, mkt_other])

# mkt_fills_t = mkt_fills

# #del mkt_fills

# # Brand Deciles by Indication
# brand_fills_ibsd = brand_fills_t[brand_fills_t['pt_category_he_ibsd']== 'IBSD']
# brand_fills_he = brand_fills_t[brand_fills_t['pt_category_he_ibsd']== 'HE']
# brand_fills_other = brand_fills_t[brand_fills_t['pt_category_he_ibsd']== 'OTHER']

# brand_ibsd = decile(brand_fills_ibsd, 'BRAND_T_6M_02')
# brand_he = decile(brand_fills_he, 'BRAND_T_6M_02')
# brand_other = decile(brand_fills_other, 'BRAND_T_6M_02')

# brand_fills = pd.concat([brand_ibsd, brand_he, brand_other])

# brand_fills_t = brand_fills

# #del brand_fills

#%% XX - Rx Fact Merge (Last Step before taking the data to Axtria server)

Rx_Fact_base = Rx_Master_v2[['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type']].drop_duplicates()
Rx_Fact_base.shape # (6707336, 7)

# Fetching the monthly new and total fills for market and brand
master1 = pd.merge(Rx_Fact_base, mkt_fills_t, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
master2 = pd.merge(master1, mkt_n_fills_t, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master1
master3 = pd.merge(master2, brand_fills_t, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master2
master4 = pd.merge(master3, brand_n_fills_t, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master3

# ttf_pre_ov, ttf_pre_nrx, ttf_pre_not_nrx, ttf_post_ov, ttf_post_nrx, ttf_post_not_nrx

master5 = pd.merge(master4, ttf_pre_ov, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master4
master6 = pd.merge(master5, ttf_pre_nrx, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master5
master7 = pd.merge(master6, ttf_pre_not_nrx, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master6
master8 = pd.merge(master7, ttf_post_ov, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master7
master9 = pd.merge(master8, ttf_post_nrx, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master8
master10 = pd.merge(master9, ttf_post_not_nrx, on = ['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type'], how = 'left')
del master9

# Dx Date
master11 = pd.merge(master10, pat_dx_dt, on = ['patient_id', 'pt_category_he_ibsd'], how = 'left')
del master10

# HCP SPEC
master12 = pd.merge(master11, Rx_Master_v4[['patient_id', 'pt_category_he_ibsd','final_category',
                                           'claim_type', 'payment_type', 'SPEC']],
                    on = ['patient_id','pt_category_he_ibsd','final_category','claim_type','payment_type'],
                    how = 'left')
del master11

# HCP Total claims potential
master13 = pd.merge(master12, pat_adj_claims_final, on = ['patient_id'], how = 'left')
del master12
master13.shape #age and patient_gender have 495454 rows with NA (6707336, 74)
master13.isna().sum()

# master13 = master13.dropna(subset=['age', 'patient_gender'])
# master13.shape
#%% Exporting

master13.to_pickle('Master_data_032223_v3.pkl')

