# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 02:27:06 2023

@author: ashish.ubana
"""

import pandas as pd
import numpy as np

master_data_v1 = pd.read_pickle(r"D:/DrFirst/Master Data/Master_data_032223_v4.pkl")
master_data_v1.columns

seed = 1234

#%% Xifaxan Master Data Sample
master_data_v1.shape 
master_data_v1.columns

master_data_v1['age_bucket'] = np.where((master_data_v1['age']<18), "<18",
                                  np.where((master_data_v1['age']>=18) & (master_data_v1['age']<31), "18-30",
                                           np.where((master_data_v1['age']>=31) & (master_data_v1['age']<41), "31-40",
                                                    np.where((master_data_v1['age']>=41) & (master_data_v1['age']<51), "41-50",
                                                             np.where((master_data_v1['age']>=51) & (master_data_v1['age']<61), "51-60",
                                                                      np.where((master_data_v1['age']>=61) & (master_data_v1['age']<71), "61-70",
                                                                               np.where((master_data_v1['age']>=71) & (master_data_v1['age']<81), "71-80","81+")))))))
master_data_v1.age_bucket.unique()      

eposed_pat = pd.read_excel(r'D:/DrFirst/Output/Exposed_pats.xlsx')
eposed_pat['patient_id'] = eposed_pat['patient_id'].astype(str)

# eposed_pat_id = eposed_pat['patient_id'].unique()
# master_data_v1 = master_data_v1.loc[~master_data_v1.patient_id.isin(eposed_pat_id), :]

data = pd.merge(master_data_v1,eposed_pat, on = 'patient_id',how='left')
data['T_C'] = data['T_C'].fillna('C')
data1 = data.loc[data['T_C']=='C']
data2= data.loc[data['T_C']=='T']

# unique_control = data1[['age_bucket', 'patient_gender', 'payment_type', 'pt_category_he_ibsd']]
# control_combinations = unique_control.drop_duplicates()

# unique_test = data2[['age_bucket', 'patient_gender', 'payment_type', 'pt_category_he_ibsd']]

# data1['key'] = data1['age_bucket'].astype(str) + "_" + data1['patient_gender'].astype(str) + "_" + data1['payment_type'].astype(str) + "_" + data1['pt_category_he_ibsd'].astype(str)
# data1_prop = data1[['key', 'patient_id']].groupby('key').count().reset_index()
# test_combinations = unique_test.drop_duplicates()
# test_combinations = 

# unique.groupby(['age_bucket', 'patient_gender', 'payment_type', 'pt_category_he_ibsd']).size()

a = data.loc[data['T_C']=='T'].pt_category_he_ibsd.value_counts()
b = data.loc[data['T_C']=='C'].pt_category_he_ibsd.value_counts()
#%% Inputs for below loops

# subsets =  [master_data_v1]
# ratios = [0.02]

#%%   HE_PRED_PT_CNT_HIGH_decile Summaries 
# df1ztests = pd.DataFrame()
# df1t = pd.DataFrame()  
# df1c = pd.DataFrame()  
# for s in subsets:
#     for r in ratios:
#         N =round(s.shape[0]*r)
#         s['N']=N
#         s['ratio'] = r
#         control = s.groupby(['age_bucket', 'patient_gender', 'payment_type', 'pt_category_he_ibsd'], group_keys=False).apply(lambda x: x.sample(int(np.rint(N*len(x)/len(s))))).sample(frac=1, random_state=seed).reset_index(drop=True)
        
# control.shape      # (134141, 77)   
# control.to_pickle(r"D:\CommercialAnalytics\Axtria\03-Salix\05-Marketing Analytics\01 - Xifaxan\Xifaxan NPP Campaign Analytics 2022\Data Review\Campaign\Dr. First\3. Processed Data\stratified_sampled_master_universe_0327_test.pkl")
#%% Stratified Random Sampling

N =  round(master_data_v1.shape[0]*0.02)

# Source: https://www.statology.org/stratified-sampling-pandas/
sample = data1.groupby(['age_bucket', 'patient_gender', 'payment_type', 'pt_category_he_ibsd'], group_keys=False).apply(lambda x: x.sample(int(np.rint(N*len(x)/len(data1))))).sample(frac=1, random_state=seed).reset_index(drop=True)
sample.shape #(134156, 76)
tool_input = sample.append(data2)
tool_input.isna().sum().to_clipboard()
tool_input.fillna(0,inplace=True)
tool_input.to_csv('tool_input_v1.csv',index='Flase')
tool_input= tool_input.loc[:,['patient_id', 'age', 'patient_gender', 'pt_category_he_ibsd','final_category', 'claim_type', 'payment_type',
                              'MKT_T_01', 'MKT_T_02','MKT_T_03', 'MKT_T_04', 'MKT_T_05', 'MKT_T_06', 'MKT_T_07', 'MKT_T_08','MKT_T_09', 'MKT_T_10',
                              'MKT_T_6M_02', 'MKT_T_4M_01', 'MKT_T_10M_01',
                              'MKT_N_01', 'MKT_N_02', 'MKT_N_03', 'MKT_N_04', 'MKT_N_05', 'MKT_N_06','MKT_N_07', 'MKT_N_08', 'MKT_N_09', 'MKT_N_10',
                              'MKT_N_6M_02','MKT_N_4M_01', 'MKT_N_10M_01',
                              'BRAND_T_01', 'BRAND_T_02', 'BRAND_T_03','BRAND_T_04', 'BRAND_T_05', 'BRAND_T_06', 'BRAND_T_07','BRAND_T_08','BRAND_T_09', 'BRAND_T_10',
                              'BRAND_T_6M_02', 'BRAND_T_4M_01','BRAND_T_10M_01',
                              'BRAND_N_01', 'BRAND_N_02', 'BRAND_N_03','BRAND_N_04', 'BRAND_N_05', 'BRAND_N_06', 'BRAND_N_07','BRAND_N_08','BRAND_N_09', 'BRAND_N_10',
                              'BRAND_N_6M_02', 'BRAND_N_4M_01','BRAND_N_10M_01',
                              'pre_ov_avg_ttf', 'pre_ov_n', 'pre_nrx_avg_ttf','pre_nrx_n', 'pre_non_nrx_avg_ttf', 'pre_non_nrx_n', 'post_ov_avg_ttf','post_ov_n', 'post_nrx_avg_ttf', 'post_nrx_n', 'post_non_nrx_avg_ttf',
                              'post_non_nrx_n', 'dx_dt', 'SPEC', 'adj_claim_count', 'age_bucket','T_C']]
# data.pt_category_he_ibsd.value_counts()
# master_data_v1.pt_category_he_ibsd.value_counts()
