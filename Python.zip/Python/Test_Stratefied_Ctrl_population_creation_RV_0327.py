# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 13:45:24 2023

@author: A2094
"""

import pandas as pd
import numpy as np


Master_data = pd.read_pickle(r'D:/DrFirst/LAAD_Data/Master_data_032723_v4_paytype_1_to_1_patient_id.pkl')
Master_data['patient_id'] = Master_data['patient_id'].astype(str)
Master_data.shape # (6707336, 74)
Master_data.columns

# Master_data.isna().sum().to_clipboard()


Test_Patients = pd.read_excel(r'D:/DrFirst/Output/mapping_check_v4_0322.xlsx',sheet_name='Test_Patients_List')
Test_Patients['patient_id'] = Test_Patients['patient_id'].astype(str)
Test_Patients['T_C'] = 'T'
Test_Patients.shape # (7346, 2)
Test_Patients.T_C.unique() # 'T'
Test_Patients.columns

Master_data2= Master_data.merge(Test_Patients, on='patient_id', how='left')
Master_data2['T_C'] =Master_data2['T_C'].fillna('C')
Master_data2.T_C.unique()
Master_data2['T_C'].value_counts()
# C    7190815
# T      11975

Master_data_v3 = Master_data2.loc[Master_data2.T_C=="T", :]
Master_data_v3.shape # (11975, 75)

Stratified_Universe = pd.read_pickle(r'D:/DrFirst/LAAD_Data/stratified_sampled_master_universe_0327_test.pkl')
Stratified_Universe.shape # (134141, 77)
Stratified_Universe.columns
Stratified_Universe.drop(columns={'age_bucket', 'N', 'ratio'}, inplace=True)

Stratified_Universe_ctrl = Stratified_Universe.loc[~(Stratified_Universe.patient_id.isin(Master_data_v3.patient_id)), :]
Stratified_Universe_ctrl.shape # (133916, 74)
Stratified_Universe_ctrl['T_C'] = "C"
Stratified_Universe_ctrl.columns

Master_data_Stratified = pd.concat([Master_data_v3,Stratified_Universe_ctrl])
Master_data_Stratified.shape # (145891, 75)

Master_data_Stratified.to_pickle(r'D:\DrFirst\LAAD_Data\Master_data_Stratified_Check.pkl')
