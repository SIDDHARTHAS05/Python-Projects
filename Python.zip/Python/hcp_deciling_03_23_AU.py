# -*- coding: utf-8 -*-
"""
Created on Thu Mar 23 02:44:14 2023

@author: ashish.ubana
"""

#%% 1 - Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime
import psycopg2

os.chdir(r'D:\DrFirst\LAAD_Data')
#%% 2 - User Inputs
min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)
mkt_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX','LACTULOSE']
# ibsd_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX']
# he_products = ['XIF550', 'LACTULOSE']
#%%

df = pd.read_pickle(r'Rx_Fact_10M_Mar22_Dec22_032023.pkl') #
df.shape #(15341647, 37)

df = df.loc[df['product'].isin(mkt_products)]
df.shape # (15314918, 37)

df = df.loc[df['claim_status']!='I']
df.shape # (12938458, 37)

wrt_dt_na_pats = df.loc[df.wrt_dt.isna(), 'patient_id'].unique()
len(wrt_dt_na_pats) # 136493
df = df.loc[~df.patient_id.isin(wrt_dt_na_pats), :]
df.shape # (12545772, 37)

df.loc[df.rx_dt<df.wrt_dt, :].shape # (1238, 37)
early_rx_pats = df.loc[df.rx_dt<df.wrt_dt, 'patient_id'].unique()
len(early_rx_pats) # 1186
df = df.loc[~df.patient_id.isin(early_rx_pats), :]
df.shape # (12543407, 37)


df['rx_month']=pd.to_datetime(df['rx_dt'].dt.year.astype(str)+'-'+
                                          df['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
len(df['rx_month'].unique())
df['rx_month'].unique()
# creating a rx column with value one for each record
df['rx']=1

#Xifaxan  HCP X Claim Type X Patient CNT
df_cnt = pd.DataFrame(df.groupby(['patient_id','ims_id','claim_type','life_cycle_claim_yn',
                                   'rx_month','product','refill_code','final_category']).agg(count=('rx','count'))).reset_index()


df_cnt['rx_PD_TOTAL']=df_cnt.loc[:,'count']

df_cnt.loc[:,'nrx_PD_TOTAL']=0
df_cnt.loc[((df_cnt['refill_code']==0)),'nrx_PD_TOTAL']=df_cnt.loc[(df_cnt['refill_code']==0),'count']
                                                                                           
len(df_cnt['rx_month'].unique())

ims_pt = pd.DataFrame(df_cnt.groupby(['ims_id','rx_month','product','final_category']).agg(rx_PD_TOTAL=('rx_PD_TOTAL',np.sum),
                                                                                     nrx_PD_TOTAL=('nrx_PD_TOTAL',np.sum))).reset_index()

len(ims_pt['rx_month'].unique())

ims_pt.columns
#%% Processing the IC DEMO data

ic_demo = pd.read_parquet(r'XIF_IC_Q1_v2_DEMO_Q1_v1_2023_APP.parquet')

# Processing ic demo file

ic_demo['IMS_ID']=ic_demo['IMS_ID'].str.zfill(7)
ic_demo.drop_duplicates(subset='IMS_ID',inplace=True)

PCP  = ["AHF","AM","CCM","CD","CHD","CIF","CIM","CLI","EM","FM","FPG","FSM","GP","GPM","GYN","HOS","HPF","HPI","HPO","IC","ID","IFP","ILI","IMA","IMG","IM","IPM","ISM","LM","MEM","MFM","NC","ND","NEP","OAN","OBG","OBS","OCC","OM","PHP","PTX","UM","VM","PUD","END"]
GI   = ["GE","HEP","THP","GS","P"]
CRS  = ["CRS","PRO"]
NPPA =["ANA","ARN","CNA","CNM","CNS","LPN","LVN","NRP","PHA","PODA","RN"]
PAIN =["ACA","ACC","ACUP","AN","APM","AR","BIN","BIP","CCA","CN","CTR","DR","ENR","EPL","ES","ESM","ESN","GO","HEM","HO","HPA","HPD","HPR","HSO","IRI","MSR","NCC","NMN","NMP","N","NRCC","NR","OAR","OCCT","OCTA","OFA","OMM","OMO","ON","ORS","OSM","OSS","OTR","PCC","PHTH","PMD","PMN","PM","PMR","PRS","RHU","RNR","RO","RP","R","SO","TR","VIR","VN","NS","SCI"]

ic_demo.loc[(ic_demo['SPECIALTY_CODE'].isin(PCP)),'SPEC_NEW']="PCP"
ic_demo.loc[(ic_demo['SPECIALTY_CODE'].isin(GI)),'SPEC_NEW']="GI"
ic_demo.loc[(ic_demo['SPECIALTY_CODE'].isin(CRS)),'SPEC_NEW']="CRS"
ic_demo.loc[(ic_demo['SPECIALTY_CODE'].isin(NPPA)),'SPEC_NEW']="NPPA"
ic_demo.loc[(ic_demo['SPECIALTY_CODE'].isin(PAIN)),'SPEC_NEW']="OTHER"
ic_demo.loc[(ic_demo['SPEC_NEW'].isin(["GI","CRS","GI(GS/P)"])),'SPEC_NEW']="GI"
ic_demo["SPEC_NEW"] = ic_demo["SPEC_NEW"].fillna("OTHER")
ic_demo.SPEC_NEW.value_counts()

### Getting specialty
ims_pt=pd.merge(ims_pt,ic_demo[['IMS_ID','SPEC_NEW', 'SPEC','NPI_ID']].rename({'IMS_ID':'ims_id'},axis='columns'),on='ims_id',how='left')
ims_pt.rename(columns = {'SPEC_NEW':'SPEC_TRUE'}, inplace = True)
ims_pt.isnull().sum(axis=0)
ims_pt['SPEC']=ims_pt['SPEC'].fillna('NOT FOUND')
ims_pt['SPEC_TRUE']=ims_pt['SPEC_TRUE'].fillna('NOT FOUND')
# ims_pt.loc[ims_pt['SPEC']=='NPPA',['SPEC']]='OTHER'
ims_pt['SPEC'].unique()
ims_pt['SPEC_TRUE'].unique()
list(ims_pt.columns)
len(ims_pt['rx_month'].unique())
ims_pt['product'].unique()


#%% Writers

# IBSD Writers
xif_ibsd_6M=ims_pt.loc[((ims_pt.rx_month >= min_date) &
                                     (ims_pt.rx_month <= max_date) & (ims_pt.final_category == 'IBSD')),['ims_id','NPI_ID','product','SPEC','rx_PD_TOTAL','nrx_PD_TOTAL']].groupby(['ims_id','NPI_ID','product','SPEC']).sum()
xif_ibsd_6M=xif_ibsd_6M.unstack('product').reset_index()
xif_ibsd_6M.fillna(0,inplace=True)
xif_ibsd_6M.columns = xif_ibsd_6M.columns.map('_'.join).str.strip('_')
xif_ibsd_6M.shape
xif_ibsd_6M['IBSD_brand_TRx_6M']=xif_ibsd_6M['rx_PD_TOTAL_XIF550']
xif_ibsd_6M['IBSD_mkt_TRx_6M']=xif_ibsd_6M['rx_PD_TOTAL_ANTIDIARRHEAL']+xif_ibsd_6M['rx_PD_TOTAL_ANTISPASMODICS']+xif_ibsd_6M['rx_PD_TOTAL_LOTRONEX']+xif_ibsd_6M['rx_PD_TOTAL_VIBERZI']+xif_ibsd_6M['rx_PD_TOTAL_XIF550']
xif_ibsd_6M=xif_ibsd_6M.loc[xif_ibsd_6M['IBSD_mkt_TRx_6M'] > 0,:]

# HE Writers
xif_he_6M=ims_pt.loc[((ims_pt.rx_month >= min_date) &
                                     (ims_pt.rx_month <= max_date) & (ims_pt.final_category == 'HE')),['ims_id','NPI_ID','product','SPEC','rx_PD_TOTAL','nrx_PD_TOTAL']].groupby(['ims_id','NPI_ID','product','SPEC']).sum()
xif_he_6M=xif_he_6M.unstack('product').reset_index()
xif_he_6M.fillna(0,inplace=True)
xif_he_6M.columns = xif_he_6M.columns.map('_'.join).str.strip('_')
xif_he_6M.columns
xif_he_6M['HE_brand_TRx_6M']=xif_he_6M['rx_PD_TOTAL_XIF550']
xif_he_6M['HE_mkt_TRx_6M']=xif_he_6M['rx_PD_TOTAL_LACTULOSE']+xif_he_6M['rx_PD_TOTAL_XIF550']
xif_he_6M=xif_he_6M.loc[xif_he_6M['HE_mkt_TRx_6M'] > 0,:]

# OTHER Writers
xif_other_6M=ims_pt.loc[((ims_pt.rx_month >= min_date) &
                                     (ims_pt.rx_month <= max_date) & (ims_pt.final_category == 'OTHER')),['ims_id','NPI_ID','product','SPEC','rx_PD_TOTAL','nrx_PD_TOTAL']].groupby(['ims_id','NPI_ID','product','SPEC']).sum()
xif_other_6M=xif_other_6M.unstack('product').reset_index()
xif_other_6M.fillna(0,inplace=True)
xif_other_6M.columns = xif_other_6M.columns.map('_'.join).str.strip('_')
xif_other_6M.columns
xif_other_6M['OTHER_brand_TRx_6M']=xif_other_6M['rx_PD_TOTAL_XIF550']
xif_other_6M['OTHER_mkt_TRx_6M']=xif_other_6M['rx_PD_TOTAL_ANTIDIARRHEAL']+xif_other_6M['rx_PD_TOTAL_ANTISPASMODICS']+xif_other_6M['rx_PD_TOTAL_LOTRONEX']+xif_other_6M['rx_PD_TOTAL_VIBERZI']+xif_other_6M['rx_PD_TOTAL_XIF550'] + xif_other_6M['rx_PD_TOTAL_LACTULOSE']
xif_other_6M=xif_other_6M.loc[xif_other_6M['OTHER_mkt_TRx_6M'] > 0,:]


# OTHER Writers
xif_brand_6M=ims_pt.loc[((ims_pt.rx_month >= min_date) &
                                      (ims_pt.rx_month <= max_date)),['ims_id','NPI_ID','product','SPEC','rx_PD_TOTAL','nrx_PD_TOTAL']].groupby(['ims_id','NPI_ID','product','SPEC']).sum()
xif_brand_6M=xif_brand_6M.unstack('product').reset_index()
xif_brand_6M.fillna(0,inplace=True)
xif_brand_6M.columns = xif_brand_6M.columns.map('_'.join).str.strip('_')
xif_brand_6M.columns
xif_brand_6M['brand_TRx_6M']=xif_brand_6M['rx_PD_TOTAL_XIF550']

#%% Deciling

def decile(df, col):
    df_decile = df.sort_values(by = col,ascending=False)
    A = df[col].sum()
    decile_cut = A/10
    
    ##Prepare cumsum for decile
    df_decile['CUMSUM'] = df_decile[col].cumsum()
    
    ##Create Decile
    df_decile[str(col)+'_decile'] = 10-(np.ceil(df_decile['CUMSUM']/decile_cut-0.000000001))+1
    df_decile.loc[df_decile[col]==0,str(col)+'_decile']=0
    
    return df_decile.drop(['CUMSUM'],axis='columns')

# Writers
xif_ibsd_6M = decile(xif_ibsd_6M,'IBSD_mkt_TRx_6M')
xif_ibsd_6M = decile(xif_ibsd_6M,'IBSD_brand_TRx_6M')
xif_ibsd_6M.rename({'ims_id':'IMS_ID'},axis='columns',inplace=True)
xif_ibsd_6M.columns
xif_he_6M = decile(xif_he_6M,'HE_mkt_TRx_6M')
xif_he_6M = decile(xif_he_6M,'HE_brand_TRx_6M')
xif_he_6M.rename({'ims_id':'IMS_ID'},axis='columns',inplace=True)

xif_other_6M = decile(xif_other_6M,'OTHER_mkt_TRx_6M')
xif_other_6M = decile(xif_other_6M,'OTHER_brand_TRx_6M')
xif_other_6M.rename({'ims_id':'IMS_ID'},axis='columns',inplace=True)

xif_brand_6M = decile(xif_brand_6M,'brand_TRx_6M')
xif_brand_6M.rename({'ims_id':'IMS_ID'},axis='columns',inplace=True)


#%% Creating final table

ims_6M=ims_pt.loc[((ims_pt.rx_month >= min_date) &
                                     (ims_pt.rx_month <= max_date)),['ims_id','NPI_ID','SPEC','rx_PD_TOTAL','nrx_PD_TOTAL']].groupby(['ims_id','NPI_ID','SPEC'], as_index=False).sum()
ims_6M.fillna(0,inplace=True)
ims_6M=ims_6M.loc[ims_6M['rx_PD_TOTAL'] > 0,:]
ims_6M = ims_6M.rename(columns={'rx_PD_TOTAL':'rx_PD_TOTAL_6M','nrx_PD_TOTAL':'nrx_PD_TOTAL_6M' })
ims_6M.columns
ims_6M.shape

final = ims_6M.merge(xif_ibsd_6M[['IMS_ID','IBSD_brand_TRx_6M','IBSD_brand_TRx_6M_decile','IBSD_mkt_TRx_6M','IBSD_mkt_TRx_6M_decile']], left_on='ims_id',right_on='IMS_ID',how='left')
final=final.drop(['IMS_ID'], axis=1)
final = final.merge(xif_he_6M[['IMS_ID','HE_brand_TRx_6M','HE_brand_TRx_6M_decile','HE_mkt_TRx_6M','HE_mkt_TRx_6M_decile']], left_on='ims_id',right_on='IMS_ID',how='left')
final=final.drop(['IMS_ID'], axis=1)
final = final.merge(xif_other_6M[['IMS_ID','OTHER_brand_TRx_6M','OTHER_brand_TRx_6M_decile','OTHER_mkt_TRx_6M','OTHER_mkt_TRx_6M_decile']], left_on='ims_id',right_on='IMS_ID',how='left')
final=final.drop(['IMS_ID'], axis=1)
final = final.merge(xif_brand_6M[['IMS_ID','brand_TRx_6M','brand_TRx_6M_decile']], left_on='ims_id',right_on='IMS_ID',how='left')
final=final.drop(['IMS_ID'], axis=1)

final.SPEC.unique()

final.columns
final.isnull().sum()

final.to_pickle('HCP_Brand_Mkt_Deciles_v6_032723.pkl')

# data = pd.read_pickle(r'D:/DrFirst/LAAD_Data/HCP_Brand_Mkt_Deciles_v4_032723.pkl')
# # data[['IBSD_brand_TRx_6M','HE_brand_TRx_6M','OTHER_brand_TRx_6M']] = data[['IBSD_brand_TRx_6M','HE_brand_TRx_6M','OTHER_brand_TRx_6M']].fillna(0)
# data['overall_brand_trx_6M'] = data['IBSD_brand_TRx_6M'].fillna(0) + data['HE_brand_TRx_6M'].fillna(0) + data['OTHER_brand_TRx_6M'].fillna(0)

# data = decile(data,'overall_brand_trx_6M')
# data.rename({'ims_id':'IMS_ID'},axis='columns',inplace=True)
# data.columns
# data.to_pickle('HCP_Brand_Mkt_Deciles_v5_032723.pkl')
