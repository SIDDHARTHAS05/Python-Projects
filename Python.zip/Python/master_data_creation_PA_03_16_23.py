# -*- coding: utf-8 -*-
"""
Created on Thu Mar 16 11:05:21 2023

@author: A3525
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\LAAD_Data')

#%% User Inputs

min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)

#%% Input Files

# Rx_Fact table (LAAD Claims)
Rx_Fact = pd.read_pickle('Rx_Fact_10M_Mar22_Dec22_031623.pkl')

# Dim Patient
Dim_Pat = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_patient.pkl")

# Dim Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")

# Exposed Patients


#%% Dim Pateint Processing

Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.columns # ['patient_id', 'patient_birth_year', 'patient_gender']
Dim_Pat.patient_id.astype(str).str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

#%% Dim provider processing

Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']

#%% Claims Data Processing - Age, Gender, Indication

Rx_Fact = Rx_Fact.loc[(Rx_Fact['new_wrt_dt'] >= min_date) & (Rx_Fact['new_wrt_dt'] <= max_date)]

Rx_pat_demo = Rx_Fact.merge(Dim_Pat, how='left', on='patient_id')

# Age
Rx_pat_demo['age'] = 2022 - Rx_pat_demo['patient_birth_year']
Rx_pat_demo['time_to_fill'] = Rx_pat_demo['rx_dt']-Rx_pat_demo['new_wrt_dt']
Rx_pat_demo['time_to_fill'] = Rx_pat_demo['time_to_fill']/np.timedelta64(1, 'D')

Rx_pat_demo.head().to_clipboard()

df1 = pd.DataFrame(Rx_pat_demo.groupby(['patient_id', 'age', 'patient_gender', 
                                        'claim_type', 'final_category']).agg(fills = ('patient_id', 'count'), 
                                                                             avg_time_to_fill = ('time_to_fill', np.mean))).reset_index()
                                                                             
                                                                             