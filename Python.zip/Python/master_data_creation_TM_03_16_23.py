# -*- coding: utf-8 -*-
"""
Created on Thu Mar 16 11:05:21 2023

@author: A3525
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\LAAD_Data')

#%% User Inputs

min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)
max_date_10m = datetime(2022, 12, 31)
ibsd_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX']
he_products = ['XIF550', 'LACTULOSE']
#%% Input Files

# Rx_Fact table (LAAD Claims)
Rx_Fact = pd.read_pickle('Rx_Fact_10M_Mar22_Dec22_031623.pkl')

# Dim Patient
Dim_Pat = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_patient.pkl")

# Dim Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")

# Exposed Patients


#%% Dim Pateint Processing

Dim_Pat.shape # (33127330, 3)
Dim_Pat.patient_id.nunique() # 33127330
Dim_Pat.columns # ['patient_id', 'patient_birth_year', 'patient_gender']
Dim_Pat.patient_id.astype(str).str.len().unique() # [10, 11,  9,  7,  6,  8,  5]
Dim_Pat['patient_id'] = Dim_Pat['patient_id'].astype(str)

#%% Dim provider processing

Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']

#%% Claims Data Processing - Age, Gender, Indication

Rx_Fact2 = Rx_Fact.loc[(Rx_Fact['new_wrt_dt'] >= min_date) & (Rx_Fact['new_wrt_dt'] <= max_date)]

Rx_pat_demo = Rx_Fact2.merge(Dim_Pat, how='left', on='patient_id')

# Age
Rx_pat_demo['age'] = 2022 - Rx_pat_demo['patient_birth_year']
Rx_pat_demo[['rx_dt','new_wrt_dt']].isna().values.any()
Rx_pat_demo['time_to_fill'] = Rx_pat_demo['rx_dt']-Rx_pat_demo['new_wrt_dt']
Rx_pat_demo.time_to_fill.isna().values.any()
Rx_pat_demo['time_to_fill'] = Rx_pat_demo['time_to_fill']/np.timedelta64(1, 'D')

Rx_pat_demo.head().to_clipboard()


#%% Market Monthly Fill Values
Rx_Fact3 = Rx_Fact.loc[(Rx_Fact['rx_dt'] >= min_date) & (Rx_Fact['rx_dt'] <= max_date_10m)]
del Rx_Fact
Rx_Fact3.new_wrt_dt.min()
Rx_Fact3['rx_month'] = pd.to_datetime(Rx_Fact3['rx_dt'].dt.year.astype(str)+'-'+
                                      Rx_Fact3['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
Rx_Fact3['rx_month'].unique()

Rx_Fact_IBSD = Rx_Fact3.loc[Rx_Fact3['product'].isin(ibsd_products)]
Rx_Fact_HE = Rx_Fact3.loc[Rx_Fact3['product'].isin(he_products)]

# Overall Market Fills
#mkt_fills = Rx_Fact3.groupby(['patient_id', 'rx_month']).size().reset_index(name='counts')
#mkt_fills_t = mkt_fills.pivot(index='patient_id', columns='rx_month', values='counts')
#mkt_fills_t = mkt_fills_t.reset_index()
#mkt_fills_t.columns
#mkt_fills_t.columns = ['patient_id', 'MKT_10', 'MKT_09', 'MKT_08', 'MKT_07', 'MKT_06', 'MKT_05', 'MKT_04', 'MKT_03', 'MKT_02', 'MKT_01']

#mkt_fills_t['MKT_6M_02'] = mkt_fills_t.loc[:,'MKT_10':'MKT_05'].sum(axis=1)
#mkt_fills_t['MKT_4M_01'] = mkt_fills_t.loc[:,'MKT_04':'MKT_01'].sum(axis=1)
#mkt_fills_t['MKT_10M_01'] = mkt_fills_t.loc[:,'MKT_10':'MKT_01'].sum(axis=1)
#mkt_fills_t.columns


# IBSD Market Fills
ibsd_mkt_fills = Rx_Fact_IBSD.groupby(['patient_id', 'rx_month']).size().reset_index(name='counts')
ibsd_mkt_fills_t = ibsd_mkt_fills.pivot(index='patient_id', columns='rx_month', values='counts')
ibsd_mkt_fills_t = ibsd_mkt_fills_t.reset_index()
ibsd_mkt_fills_t.columns
ibsd_mkt_fills_t.columns = ['patient_id', 'IBSD_MKT_10', 'IBSD_MKT_09', 'IBSD_MKT_08', 'IBSD_MKT_07', 'IBSD_MKT_06', 'IBSD_MKT_05', 'IBSD_MKT_04', 'IBSD_MKT_03', 'IBSD_MKT_02', 'IBSD_MKT_01']

ibsd_mkt_fills_t['IBSD_MKT_6M_02'] = ibsd_mkt_fills_t.loc[:,'IBSD_MKT_10':'IBSD_MKT_05'].sum(axis=1)
ibsd_mkt_fills_t['IBSD_MKT_4M_01'] = ibsd_mkt_fills_t.loc[:,'IBSD_MKT_04':'IBSD_MKT_01'].sum(axis=1)
ibsd_mkt_fills_t['IBSD_MKT_10M_01'] = ibsd_mkt_fills_t.loc[:,'IBSD_MKT_10':'IBSD_MKT_01'].sum(axis=1)
ibsd_mkt_fills_t.columns

# HE Market Fills
he_mkt_fills = Rx_Fact_HE.groupby(['patient_id', 'rx_month']).size().reset_index(name='counts')
he_mkt_fills_t = he_mkt_fills.pivot(index='patient_id', columns='rx_month', values='counts')
he_mkt_fills_t = he_mkt_fills_t.reset_index()
he_mkt_fills_t.columns
he_mkt_fills_t.columns = ['patient_id', 'HE_MKT_10', 'HE_MKT_09', 'HE_MKT_08', 'HE_MKT_07', 'HE_MKT_06', 'HE_MKT_05', 'HE_MKT_04', 'HE_MKT_03', 'HE_MKT_02', 'HE_MKT_01']

he_mkt_fills_t['HE_MKT_6M_02'] = he_mkt_fills_t.loc[:,'HE_MKT_10':'HE_MKT_05'].sum(axis=1)
he_mkt_fills_t['HE_MKT_4M_01'] = he_mkt_fills_t.loc[:,'HE_MKT_04':'HE_MKT_01'].sum(axis=1)
he_mkt_fills_t['HE_MKT_10M_01'] = he_mkt_fills_t.loc[:,'HE_MKT_10':'HE_MKT_01'].sum(axis=1)
he_mkt_fills_t.columns

#%% Brand Monthly Fills

Rx_Fact_Brand = Rx_Fact3[Rx_Fact3['product']=='XIF550']

# Brand Fills
brand_fills = Rx_Fact_Brand.groupby(['patient_id', 'rx_month']).size().reset_index(name='counts')
brand_fills_t = brand_fills.pivot(index='patient_id', columns='rx_month', values='counts')
brand_fills_t = brand_fills_t.reset_index()
brand_fills_t.columns
brand_fills_t.columns = ['patient_id', 'BRAND_10', 'BRAND_09', 'BRAND_08', 'BRAND_07', 'BRAND_06', 'BRAND_05', 'BRAND_04', 'BRAND_03', 'BRAND_02', 'BRAND_01']

brand_fills_t['BRAND_6M_02'] = brand_fills_t.loc[:,'BRAND_10':'BRAND_05'].sum(axis=1)
brand_fills_t['BRAND_4M_01'] = brand_fills_t.loc[:,'BRAND_04':'BRAND_01'].sum(axis=1)
brand_fills_t['BRAND_10M_01'] = brand_fills_t.loc[:,'BRAND_10':'BRAND_01'].sum(axis=1)
brand_fills_t.columns

#%%

#Rx_pat_demo = Rx_pat_demo.merge(mkt_fills_t, how='left', on='patient_id')
Rx_pat_demo = Rx_pat_demo.merge(ibsd_mkt_fills_t, how='left', on='patient_id')
Rx_pat_demo = Rx_pat_demo.merge(he_mkt_fills_t, how='left', on='patient_id')
Rx_pat_demo = Rx_pat_demo.merge(brand_fills_t, how='left', on='patient_id')


df1 = pd.DataFrame(Rx_pat_demo.groupby(['patient_id', 'age', 'patient_gender', 
                                        'claim_type', 'final_category']).agg(fills = ('patient_id', 'count'), 
                                                                             avg_time_to_fill = ('time_to_fill', np.mean))).reset_index()
                                                                             
                                                                            