# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 17:58:12 2023

@author: a3900
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Master Data')

#%%

Master_data = pd.read_pickle(r'Master_data_032123_v2.pkl')
Master_data['patient_id'] = Master_data['patient_id'].astype(str)

Test_Patients = pd.read_excel(r'D:\DrFirst\Output\Test_Patients.xlsx')
Test_Patients['patient_id'] = Test_Patients['patient_id'].astype(str)
Test_Patients.T_C.unique()

Master_data2= Master_data.merge(Test_Patients[['patient_id','T_C']], left_on='patient_id',right_on='patient_id', how='left')
Master_data2['T_C'] =Master_data2['T_C'].fillna(0)
Master_data2.T_C.unique()
Master_data2.T_C.sum()

Master_data2['TC_Flag'] = np.where(Master_data2['T_C']==1,"T","C")
Master_data2= Master_data2.drop(columns=['T_C'])

# Count of Test and Control Patients: 7,190,825 Control and 20,967 Test
Master_data2.groupby(['TC_Flag'],as_index=False)['patient_id'].count()

#%%
Master_data2.to_pickle('Master_data_032123_v3.pkl')



