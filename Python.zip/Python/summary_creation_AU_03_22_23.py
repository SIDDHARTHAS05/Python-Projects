# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 08:56:21 2023

@author: A3944
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Output')

#%%

Master_data = pd.read_pickle(r'D:/DrFirst/Master Data/Master_data_032223_v4.pkl')
Master_data['patient_id'] = Master_data['patient_id'].astype(str)
Master_data.shape # (6707336, 74)
Master_data.columns
# Master_data.isna().sum().to_clipboard()

Test_Patients = pd.read_excel(r'D:/DrFirst/Output/mapping_check_v4_0322.xlsx',sheet_name='Test_Patients_List')
Test_Patients['patient_id'] = Test_Patients['patient_id'].astype(str)
Test_Patients['T_C'] = 'T'
Test_Patients.shape # (7346, 2)
Test_Patients.T_C.unique() # 'T'
Test_Patients.columns

Master_data2= Master_data.merge(Test_Patients, on='patient_id', how='left')
Master_data2['T_C'] =Master_data2['T_C'].fillna('C')
Master_data2.T_C.unique()
Master_data2['T_C'].value_counts()
# C    7190815
# T      11975

Master_data2.loc[Master_data2.T_C=='T','patient_id'].nunique() # 7308
# a = Master_data2.loc[(Master_data2['T_C'] == 'T') & (Master_data2['MKT_T_6M_02'] >0)]['patient_id'].nunique()
# b = Master_data2.loc[(Master_data2['T_C'] == 'T') & (Master_data2['BRAND_N_6M_02'] >0)]['patient_id'].nunique()
#%% Summaries

Master_data2.columns
Master_data2.dx_dt.nunique()
Master_data2.patient_id.nunique() # 5796975
Master_data2[['patient_id','pt_category_he_ibsd']].drop_duplicates().shape # (5796975, 2)

#Splitting by Indication
ibsd_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='IBSD']
he_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='HE']
other_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='OTHER']

# Test Only & Splitting by Indication
ibsd_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='IBSD')&(Master_data2['T_C']=='T')]
he_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='HE')&(Master_data2['T_C']=='T')]
other_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='OTHER')&(Master_data2['T_C']=='T')]

#%%


# Master_data2.isna().sum().to_clipboard()
Master_data2.dx_dt.dtype

Master_data2.loc[:, 'MKT_N_10':'post_non_nrx_n'] = Master_data2.loc[:, 'MKT_N_10':'post_non_nrx_n'].fillna(0)


#%% HCP Data Creation 

mapping = pd.read_excel(r'D:/DrFirst/Output/Exposed_HCPs.xlsx')
mapping['npi_id'] = mapping['npi_id'].astype(str)
mapping.rename(columns={'npi_id':'NPI_ID'},inplace=True)
mapping['T_C'] = 'T'

hcp_deciles = pd.read_pickle(r'D:/DrFirst/LAAD_Data/HCP_Brand_Mkt_Deciles_v3_032323.pkl')
hcp_deciles['NPI_ID'] = hcp_deciles['NPI_ID'].astype(str)
hcp_deciles.drop_duplicates(subset =['NPI_ID'],inplace=True)

hcp_data = hcp_deciles.merge(mapping, on='NPI_ID', how='left')
hcp_data['T_C'] =hcp_data['T_C'].fillna('C')

#Splitting by Indication
ibsd_test_hcps = hcp_data.loc[~hcp_data.IBSD_mkt_TRx_6M_decile.isna()]
he_test_hcps = hcp_data.loc[~hcp_data.HE_mkt_TRx_6M_decile.isna()]
other_test_hcps = hcp_data.loc[~hcp_data.OTHER_mkt_TRx_6M_decile.isna()]

#%% HCP Summaries pt 1 (repeat for only 3 test subsets)

# Change input dataset in line 152 to get different results for each pt category
# Options : [ibsd_test_hcps, he_test_hcps, other_test_hcps]

mapping = pd.read_csv(r'D:/DrFirst/Output/test_hcp_mapping_file_032423.csv')
mapping['ims_id']= mapping['ims_id'].astype(float)
mapping.shape # (13357, 2)
mapping.columns

test_hcp_data2 = ibsd_test_hcps.copy()

# HCPs by specialty
hcps_by_spec = test_hcp_data2.groupby(['SPEC','T_C'], as_index=False)['ims_id'].count()
hcps_by_spec.to_clipboard()
# Number of HCPs within Test patient-count buckets
# hcp_pat_counts = test_hcp_data2.groupby(['ims_id'], as_index=False)['patient_id'].count()
# hcp_pat_counts=hcp_pat_counts.rename(columns={'patient_id':'pat_count'})
# a=len(hcp_pat_counts[hcp_pat_counts['pat_count']==1])
# b=len(hcp_pat_counts[hcp_pat_counts['pat_count']==2])
# c=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=3)&(hcp_pat_counts['pat_count']<=20)])
# d=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=21)&(hcp_pat_counts['pat_count']<=40)])
# e=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=41)&(hcp_pat_counts['pat_count']<=60)])
# f=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=61)])

# pat_counts = pd.DataFrame([['1',a],['2',b], ['3-20',c],['21-40',d],['41-60',e],['61+',f]])
# pat_counts.columns=['Patient Bucket','Number of HCPs']
# pat_counts.to_clipboard()

# HCPs and Test Patients by Diagnosis Month
# hcp_pat_months = test_hcp_data2.groupby(['dx_month'], as_index=False)['ims_id','patient_id'].count()
# hcp_pat_months.to_clipboard()


#%% HCP Summaries pt 2 (No need to repeat)

# Count of HCPs by Brand Decile
ibsd_brand_decile = ibsd_test_hcps.groupby(['IBSD_brand_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
ibsd_brand_decile.to_clipboard()
he_brand_decile = he_test_hcps.groupby(['HE_brand_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
he_brand_decile.to_clipboard()
other_brand_decile = other_test_hcps.groupby(['OTHER_brand_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
other_brand_decile.to_clipboard()


# Count of HCPs by Market Decile
ibsd_mkt_decile = ibsd_test_hcps.groupby(['IBSD_mkt_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
ibsd_mkt_decile.to_clipboard()
he_mkt_decile = he_test_hcps.groupby(['HE_mkt_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
he_mkt_decile.to_clipboard()
other_mkt_decile = other_test_hcps.groupby(['OTHER_mkt_TRx_6M_decile','T_C'], as_index=False)['ims_id'].count()
other_mkt_decile.to_clipboard()








