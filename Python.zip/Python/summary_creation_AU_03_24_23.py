# -*- coding: utf-8 -*-
"""
Created on Fri Mar 24 11:11:59 2023

@author: A3944
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Output')

#%% 2 - User Inputs
min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)
max_date_10m = datetime(2022, 12, 31)
# ibsd_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX']
# he_products = ['XIF550', 'LACTULOSE']
mkt_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX','LACTULOSE']


#%% 3 - Input Files
# Rx_Fact table (LAAD Claims)
Rx_Fact = pd.read_pickle(r'D:/DrFirst/LAAD_Data/Rx_Fact_10M_Mar22_Dec22_032023.pkl')
Rx_Fact.shape # (15341647, 36)
Rx_Fact.wrt_dt.min() # 2022-03-01
Rx_Fact.wrt_dt.max() # 2022-12-31
Rx_Fact.rx_dt.min() # 2022-02-28
Rx_Fact.rx_dt.max() # 2022-12-31

Rx_Fact = Rx_Fact.loc[Rx_Fact['product'].isin(mkt_products)]
Rx_Fact.shape # (15314918, 37)

Rx_Fact = Rx_Fact.loc[Rx_Fact['claim_status']!='I']
Rx_Fact.shape # (12938458, 37)

Rx_Fact.isna().sum() # 294625 wrt_dt NA
Rx_Fact.loc[Rx_Fact.rx_dt<Rx_Fact.wrt_dt, :].shape # (1242, 37)
wrt_dt_na_pats = Rx_Fact.loc[Rx_Fact.wrt_dt.isna(), 'patient_id'].unique()
len(wrt_dt_na_pats) # 136493
Rx_Fact_v2 = Rx_Fact.loc[~Rx_Fact.patient_id.isin(wrt_dt_na_pats), :]
Rx_Fact_v2.shape # (12545772, 37)

early_rx_pats = Rx_Fact_v2.loc[Rx_Fact_v2.rx_dt<Rx_Fact_v2.wrt_dt, 'patient_id'].unique()
len(early_rx_pats) # 1186
Rx_Fact_v2 = Rx_Fact_v2.loc[~Rx_Fact_v2.patient_id.isin(early_rx_pats), :]
Rx_Fact_v2.shape # (12543407, 37)

Rx_Fact_v2['rx_month']=pd.to_datetime(Rx_Fact_v2['rx_dt'].dt.year.astype(str)+'-'+
                                          Rx_Fact_v2['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
len(Rx_Fact_v2['rx_month'].unique())
Rx_Fact_v2['rx_month'].unique()

mapping = pd.read_csv(r'D:/DrFirst/Output/test_hcp_mapping_file_032423.csv')
mapping['patient_id'] = mapping['patient_id'].astype(str)
mapping['npi'] = mapping['npi'].astype(str)
mapping['ims_id'].isna().sum()
mapping['ims_id']=mapping['ims_id'].astype(str)
mapping['ims_id'].str.len().max() # 9
mapping['ims_id']=mapping['ims_id'].str.zfill(9)
mapping['ims_id']=mapping['ims_id'].str[0:7]
mapping.columns # ['patient_id', 'npi', 'ims_id']
mapping.patient_id.nunique() # 7346
test_hcps_list = mapping['ims_id'].unique()
mapping['T_C'] = 'T'

Rx_Fact_summary_v1 = Rx_Fact_v2.loc[Rx_Fact_v2.ims_id.isin(test_hcps_list), ['patient_id','ims_id','pt_category_he_ibsd','final_category','rx_dt','wrt_dt','rx_month']]
Rx_Fact_summary_v1.wrt_dt.min() # wrt_dt
Rx_Fact_summary_v1.wrt_dt.max()

summary_pre_overall = Rx_Fact_summary_v1.loc[Rx_Fact_summary_v1.wrt_dt<=max_date,:].groupby(['ims_id','pt_category_he_ibsd'])['patient_id'].nunique().reset_index()
summary_pre_overall.to_clipboard()

pat_count = pd.merge(Rx_Fact_v2[['patient_id','ims_id','pt_category_he_ibsd','final_category','rx_dt','wrt_dt','rx_month']],mapping,on=['patient_id','ims_id'],how='left')
pat_count['T_C'] = pat_count['T_C'].fillna('C')
# pat_count.to_excel('HCP_patient_summary.xlsx',index=False)

summ_exposed_pre = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>=min_date) & (pat_count['wrt_dt']<=max_date)].groupby(['ims_id','pt_category_he_ibsd'])['patient_id'].nunique()
summ_exposed_pre.to_clipboard()

summ_exposed_post = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>max_date) & (pat_count['wrt_dt']<=max_date_10m)].groupby(['ims_id','pt_category_he_ibsd'])['patient_id'].nunique()
summ_exposed_post.to_clipboard()


