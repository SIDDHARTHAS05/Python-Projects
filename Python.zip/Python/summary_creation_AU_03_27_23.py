# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 07:28:21 2023

@author: A3944
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Output')

#%% 2 - User Inputs
min_date = datetime(2022, 3, 1)
max_date = datetime(2022, 8, 31)
max_date_10m = datetime(2022, 12, 31)
# ibsd_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX']
# he_products = ['XIF550', 'LACTULOSE']
mkt_products = ['ANTISPASMODICS', 'ANTIDIARRHEAL', 'XIF550', 'VIBERZI', 'LOTRONEX','LACTULOSE']

#%% HCP Data Creation 

mapping = pd.read_excel(r'D:/DrFirst/Output/Exposed_HCPs.xlsx')
mapping['npi_id'] = mapping['npi_id'].astype(str)
mapping.rename(columns={'npi_id':'NPI_ID'},inplace=True)
mapping['T_C'] = 'T'

hcp_deciles = pd.read_pickle(r'D:/DrFirst/LAAD_Data/HCP_Brand_Mkt_Deciles_v6_032723.pkl')
hcp_deciles['NPI_ID'] = hcp_deciles['NPI_ID'].astype(str)
hcp_deciles.drop_duplicates(subset =['NPI_ID'],inplace=True)

hcp_data = hcp_deciles.merge(mapping, on='NPI_ID', how='left')
hcp_data['T_C'] =hcp_data['T_C'].fillna('C')

#Splitting by Indication
# overall = hcp_data.loc[~hcp_data.brand_TRx_6M_decile.isna()]
ibsd_test_hcps = hcp_data.loc[~hcp_data.IBSD_mkt_TRx_6M_decile.isna()]
he_test_hcps = hcp_data.loc[~hcp_data.HE_mkt_TRx_6M_decile.isna()]
other_test_hcps = hcp_data.loc[~hcp_data.OTHER_mkt_TRx_6M_decile.isna()]

#%% HCP Summaries pt 1 (repeat for only 3 test subsets)

# Change input dataset in line 47 to get different results for each pt category
# Options : [ibsd_test_hcps, he_test_hcps, other_test_hcps]

test_hcp_data2 = other_test_hcps.copy()

# HCPs by specialty
# Overall
hcp_data.loc[hcp_data['T_C']=="T","ims_id"].nunique() # 4321
hcps_by_spec = hcp_data.groupby(['SPEC','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_spec.to_clipboard()

hcp_data['brand_TRx_6M_decile'] = hcp_data['brand_TRx_6M_decile'].fillna(0)
hcps_by_brand = hcp_data.groupby(['brand_TRx_6M_decile','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_brand.to_clipboard()

# indication
hcps_by_spec = test_hcp_data2.groupby(['SPEC','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_spec.to_clipboard()

# indication
hcps_by_spec = test_hcp_data2.groupby(['SPEC','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_spec.to_clipboard()

# Brand Decile
hcps_by_spec = test_hcp_data2.groupby(['OTHER_brand_TRx_6M_decile','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_spec.to_clipboard()

# Market decile
hcps_by_spec = test_hcp_data2.groupby(['OTHER_mkt_TRx_6M_decile','T_C'], as_index=False)['ims_id'].nunique()
hcps_by_spec.to_clipboard()

#%% 3 - Input Files
# Rx_Fact table (LAAD Claims)
Rx_Fact = pd.read_pickle(r'D:/DrFirst/LAAD_Data/Rx_Fact_10M_Mar22_Dec22_032023.pkl')

# Don't use this, this is for check purpose only
# claim_id_df  = pd.read_excel("D:/DrFirst/Output/claims_id_test.xlsx")
# claim_id_df.columns
# claim_id_df.dtypes
# claim_id_df['claim_id'] = claim_id_df['claim_id'].astype(str)
# Rx_Fact.claim_id.str.len().unique() # [20, 12]
# claim_id_df.claim_id.str.len().unique() # [20, 12]
# Rx_Fact_2 = Rx_Fact.loc[Rx_Fact.claim_id.isin(claim_id_df.claim_id), :]
# Rx_Fact_2.claim_status.value_counts()

Rx_Fact.shape # (15341647, 36)
Rx_Fact.wrt_dt.min() # 2022-03-01
Rx_Fact.wrt_dt.max() # 2022-12-31
Rx_Fact.rx_dt.min() # 2022-02-28
Rx_Fact.rx_dt.max() # 2022-12-31

Rx_Fact = Rx_Fact.loc[Rx_Fact['product'].isin(mkt_products)]
Rx_Fact.shape # (15314918, 37)

Rx_Fact = Rx_Fact.loc[Rx_Fact['claim_status']!='I']
Rx_Fact.shape # (12938458, 37)

wrt_dt_na_pats = Rx_Fact.loc[Rx_Fact.wrt_dt.isna(), 'patient_id'].unique()
len(wrt_dt_na_pats) # 136493
Rx_Fact_v2 = Rx_Fact.loc[~Rx_Fact.patient_id.isin(wrt_dt_na_pats), :]
Rx_Fact_v2.shape # (12545772, 37)

Rx_Fact.loc[Rx_Fact.rx_dt<Rx_Fact.wrt_dt, :].shape # (1242, 37)
early_rx_pats = Rx_Fact_v2.loc[Rx_Fact_v2.rx_dt<Rx_Fact_v2.wrt_dt, 'patient_id'].unique()
len(early_rx_pats) # 1186
Rx_Fact_v2 = Rx_Fact_v2.loc[~Rx_Fact_v2.patient_id.isin(early_rx_pats), :]
Rx_Fact_v2.shape # (12543407, 37)

Rx_Fact_v2.wrt_dt.min() # 2022-03-01
Rx_Fact_v2.wrt_dt.max() # 2022-12-31
Rx_Fact_v2.rx_dt.min() # 2022-03-01
Rx_Fact_v2.rx_dt.max() # 2022-12-31

# Dim_Provider
Dim_Provider = pd.read_pickle(r"D:/DrFirst/LAAD_Data/dim_provider.pkl")
Dim_Provider.shape # (2624439, 2)
Dim_Provider.columns # ['provider_id', 'npi_number']
Dim_Provider.isna().sum() # 52375 npi_number NAs
Dim_Provider.provider_id.nunique() # 2624438

# Merging Dim_Provider with Rx_fact
Rx_Fact_v2.provider_id.astype(str).str.len().unique() # [ 9, 10,  3,  8,  7, 6]
Dim_Provider.provider_id.astype(str).str.len().unique() # [ 6,  7,  8,  9,  3,  4,  5, 10]

Rx_Fact_v2.provider_id # format 7626100.0
Dim_Provider.provider_id # format 29777901.0

Rx_Fact_v2['provider_id'] = Rx_Fact_v2['provider_id'].astype(str)
Dim_Provider['provider_id'] = Dim_Provider['provider_id'].astype(str)

Rx_Fact_v2 = Rx_Fact_v2.merge(Dim_Provider, how='left', on='provider_id')
Rx_Fact_v2.shape # (12543407, 38)

Rx_Fact_v2.npi_number.isna().sum() # 104,304 npi null
Rx_Fact_v2.ims_id.isna().sum() # 64,070 npi null
Rx_Fact_v2.columns
Rx_Fact_v2.ims_id.str.len().unique() # [ 7., nan]
Rx_Fact_v2.npi_number.str.len().unique() # [ 10., nan]
# Rx_Fact_v2['rx_month']=pd.to_datetime(Rx_Fact_v2['rx_dt'].dt.year.astype(str)+'-'+
#                                           Rx_Fact_v2['rx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')
# len(Rx_Fact_v2['rx_month'].unique())
# Rx_Fact_v2['rx_month'].unique()

mapping = pd.read_csv(r'D:/DrFirst/Output/test_hcp_mapping_file_032423.csv')
mapping['patient_id'] = mapping['patient_id'].astype(str)
mapping['npi'] = mapping['npi'].astype(str)
mapping['ims_id'].isna().sum()
mapping['ims_id']=mapping['ims_id'].astype(str)
mapping['ims_id'].str.len().max() # 9
mapping['ims_id']=mapping['ims_id'].str.zfill(9)
mapping['ims_id']=mapping['ims_id'].str[0:7]
mapping.columns # ['patient_id', 'npi', 'ims_id']
mapping.patient_id.nunique() # 7308
mapping['T_C'] = 'T'
mapping = mapping.rename(columns={'npi':'npi_number' })

# test_hcps_list = mapping['ims_id'].unique()

# test_hcps_list = mapping['npi'].unique()
# test_patients_list = mapping['patient_id'].unique()

# Rx_Fact_summary_v1 = Rx_Fact_v2.loc[Rx_Fact_v2.npi_number.isin(test_hcps_list), ['patient_id','ims_id','pt_category_he_ibsd','final_category','rx_dt','wrt_dt','npi_number']]
# Rx_Fact_summary_v1.wrt_dt.min() # wrt_dt
# Rx_Fact_summary_v1.wrt_dt.max()

# Rx_Fact_summary_v1 = Rx_Fact_v2.loc[Rx_Fact_v2.npi_number.isin(test_hcps_list)]
# Rx_Fact_summary_v1 = Rx_Fact_v2.loc[Rx_Fact_v2.patient_id.isin(test_patients_list)]
                                    
# summary_pre_overall = Rx_Fact_summary_v1.loc[Rx_Fact_summary_v1.wrt_dt<=max_date,:].groupby(['npi_number','pt_category_he_ibsd'])['patient_id'].nunique().reset_index()
# summary_pre_overall.to_clipboard()

# summary_post_overall = Rx_Fact_summary_v1.loc[(Rx_Fact_summary_v1.wrt_dt>max_date) & (Rx_Fact_summary_v1.wrt_dt<=max_date_10m)].groupby(['npi_number','pt_category_he_ibsd'])['patient_id'].nunique().reset_index()
# summary_post_overall.to_clipboard()

pat_count = pd.merge(Rx_Fact_v2[['patient_id','ims_id','pt_category_he_ibsd','final_category','rx_dt','wrt_dt','npi_number']],mapping,on=['patient_id','npi_number'],how='left')
pat_count['T_C'] = pat_count['T_C'].fillna('C')
# pat_count.to_excel('HCP_patient_summary.xlsx',index=False)

pat_count.loc[pat_count['T_C']=="T","patient_id"].nunique() # 7255

summ_exposed_pre = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>=min_date) & (pat_count['wrt_dt']<=max_date)].groupby(['npi_number'])['patient_id'].nunique()
summ_exposed_pre.to_clipboard()

summ_exposed_post = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>max_date) & (pat_count['wrt_dt']<=max_date_10m)].groupby(['npi_number'])['patient_id'].nunique()
summ_exposed_post.to_clipboard()

summ_exposed_pre_indication = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>=min_date) & (pat_count['wrt_dt']<=max_date) & (pat_count['pt_category_he_ibsd']=='OTHER')].groupby(['npi_number','pt_category_he_ibsd'])['patient_id'].nunique()
summ_exposed_pre_indication.to_clipboard()

summ_exposed_post_indication = pat_count.loc[(pat_count['T_C']=='T') & (pat_count['wrt_dt']>max_date) & (pat_count['wrt_dt']<=max_date_10m) & (pat_count['pt_category_he_ibsd']=='OTHER')].groupby(['npi_number','pt_category_he_ibsd'])['patient_id'].nunique()
summ_exposed_post_indication.to_clipboard()