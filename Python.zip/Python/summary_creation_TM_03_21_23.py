# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 19:44:42 2023

@author: a3900
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Master Data')

df = pd.read_pickle(r'Master_data_032123_v3.pkl')
#%% Summaries
df.columns
df.dx_dt.nunique()

#Splitting by Indication
ibsd_pats = df[df['pt_category_he_ibsd']=='IBSD']
he_pats = df[df['pt_category_he_ibsd']=='HE']
other_pats = df[df['pt_category_he_ibsd']=='OTHER']

# Test Only & Splitting by Indication
ibsd_test_pats = df[(df['pt_category_he_ibsd']=='IBSD')&(df['TC_Flag']=='T')]
he_test_pats = df[(df['pt_category_he_ibsd']=='HE')&(df['TC_Flag']=='T')]
other_test_pats = df[(df['pt_category_he_ibsd']=='OTHER')&(df['TC_Flag']=='T')]

#%%

# Overall
overall_branded_sums = df.groupby(['pt_category_he_ibsd'], as_index=False)['BRAND_T_10', 'BRAND_T_09', 'BRAND_T_08','BRAND_T_07', 'BRAND_T_06', 'BRAND_T_05', 'BRAND_T_04', 'BRAND_T_03','BRAND_T_02', 'BRAND_T_01'].sum()
overall_branded_sums

overall_mkt_sums = df.groupby(['pt_category_he_ibsd'], as_index=False)['MKT_T_10', 'MKT_T_09','MKT_T_08', 'MKT_T_07', 'MKT_T_06', 'MKT_T_05', 'MKT_T_04', 'MKT_T_03','MKT_T_02', 'MKT_T_01'].sum()
overall_mkt_sums

overall_payment_counts = df.groupby(['payment_type'],as_index=False)['patient_id'].count()
overall_payment_counts


# Test Only
test_branded_sums = df[(df['TC_Flag']=='T')].groupby(['pt_category_he_ibsd'], as_index=False)['BRAND_T_10', 'BRAND_T_09', 'BRAND_T_08','BRAND_T_07', 'BRAND_T_06', 'BRAND_T_05', 'BRAND_T_04', 'BRAND_T_03','BRAND_T_02', 'BRAND_T_01'].sum()
test_branded_sums

test_mkt_sums = df[(df['TC_Flag']=='T')].groupby(['pt_category_he_ibsd'], as_index=False)['MKT_T_10', 'MKT_T_09','MKT_T_08', 'MKT_T_07', 'MKT_T_06', 'MKT_T_05', 'MKT_T_04', 'MKT_T_03','MKT_T_02', 'MKT_T_01'].sum()
test_mkt_sums

test_payment_counts = df[(df['TC_Flag']=='T')].groupby(['payment_type'],as_index=False)['patient_id'].count()
test_payment_counts

#%%

df['post_ttf_seg'] = np.where(df['post_nrx_avg_ttf']>60,">60",np.where(df['post_nrx_avg_ttf']<60,"<60","60"))

# Overall
post_ttf_pat_counts = df.groupby(['pt_category_he_ibsd','post_ttf_seg'],as_index=False)['patient_id'].count()
post_ttf_pat_counts

# Test Only
test_post_ttf_pat_counts = df[(df['TC_Flag']=='T')].groupby(['pt_category_he_ibsd','post_ttf_seg'],as_index=False)['patient_id'].count()
test_post_ttf_pat_counts

#%%

with pd.ExcelWriter('D:\DrFirst\Output\summaries_TM_03_21_23.xlsx') as writer:
    overall_branded_sums.to_excel(writer, sheet_name='Brand_Monthly_Sums',index=False)
    overall_mkt_sums.to_excel(writer, sheet_name='Mkt_Monthly_Sums',index=False)
    overall_payment_counts.to_excel(writer, sheet_name='Count_of_Pats_by_Type',index=False)
    test_branded_sums.to_excel(writer, sheet_name='Test_Brand_Monthly_Sums',index=False)
    test_mkt_sums.to_excel(writer, sheet_name='Test_Mkt_Monthly_Sums',index=False)
    test_payment_counts.to_excel(writer, sheet_name='Count_of_Test_Pats_by_Type',index=False)
    post_ttf_pat_counts.to_excel(writer, sheet_name='TTF_Pat_Counts',index=False)
    test_post_ttf_pat_counts.to_excel(writer, sheet_name='TTF_Test_Pat_Counts',index=False)




