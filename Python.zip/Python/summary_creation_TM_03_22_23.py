# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 08:56:21 2023

@author: A3944
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 17:58:12 2023

@author: a3900
"""

#%% Import libraries
import pandas as pd
import numpy as np
import os
from datetime import datetime

os.chdir(r'D:\DrFirst\Master Data')

#%% Patient-Level Data

Master_data = pd.read_pickle(r'Master_data_032223_v4.pkl')
Master_data['patient_id'] = Master_data['patient_id'].astype(str)
Master_data.shape # (6707336, 74)
Master_data.columns
# Master_data.isna().sum().to_clipboard()

Test_Patients = pd.read_excel(r'D:/DrFirst/Output/mapping_check_v4_0322.xlsx',sheet_name='Test_Patients_List')
Test_Patients['patient_id'] = Test_Patients['patient_id'].astype(str)
Test_Patients['T_C'] = 'T'
Test_Patients.shape # (7346, 2)
Test_Patients.T_C.unique() # 'T'
Test_Patients.columns

Master_data2= Master_data.merge(Test_Patients, on='patient_id', how='left')
Master_data2['T_C'] =Master_data2['T_C'].fillna('C')
Master_data2.T_C.unique()
Master_data2['T_C'].value_counts()
# C    7190815
# T      11975

Master_data2.loc[Master_data2.T_C=='T','patient_id'].nunique() # 7308

Master_data2["age_buc"] =np.where((Master_data2["age"]<18), "<18",
                                        np.where((Master_data2["age"]>=18) & (Master_data2["age"]<31), "18-30",
                                                 np.where((Master_data2["age"]>=31) & (Master_data2["age"]<41), "31-40",
                                                          np.where((Master_data2["age"]>=41) & (Master_data2["age"]<51), "41-50",
                                                                   np.where((Master_data2["age"]>=51) & (Master_data2["age"]<61), "51-60",
                                                                            np.where((Master_data2["age"]>=61) & (Master_data2["age"]<71), "61-70",
                                                                                     np.where((Master_data2["age"]>=71) & (Master_data2["age"]<81), "71-80", "81+")))))))

# Cannot get to work
#Master_data2['dx_dt'] = Master_data2['dx_dt'].fillna('0000-00-00 00:00:00')
#Master_data2['dx_month'] = pd.to_datetime(Master_data2['dx_dt'].dt.year.astype(str)+'-'+
#                                          Master_data2['dx_dt'].dt.month.astype(str).str.zfill(2)+'-01',format='%Y-%m-%d')

#%% Indication-Test Level Subset Creation

Master_data2.columns
Master_data2.dx_dt.nunique()
Master_data2.patient_id.nunique() # 5796975
Master_data2[['patient_id','pt_category_he_ibsd']].drop_duplicates().shape # (5796975, 2)

#Splitting by Indication
ibsd_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='IBSD']
he_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='HE']
other_pats = Master_data2[Master_data2['pt_category_he_ibsd']=='OTHER']

# Test Only & Splitting by Indication
ibsd_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='IBSD')&(Master_data2['T_C']=='T')]
he_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='HE')&(Master_data2['T_C']=='T')]
other_test_pats = Master_data2[(Master_data2['pt_category_he_ibsd']=='OTHER')&(Master_data2['T_C']=='T')]
test_overall = Master_data2[(Master_data2['T_C']=='T')]
#%% Patient Summaries pt 1 (repeat for all 6 subsets)

# Change input dataset in line 81 to get different results for each pt category
# Options : [ibsd_pats, he_pats, other_pats, ibsd_test_pats, he_test_pats, other_test_pats]
Master_data3 = other_test_pats.copy()

Master_data3.isna().sum().to_clipboard()
Master_data3.dx_dt.dtype

Master_data3.loc[:, 'MKT_N_10':'post_non_nrx_n'] = Master_data3.loc[:, 'MKT_N_10':'post_non_nrx_n'].fillna(0)

#%% Patient Summaries pt 2 (repeat for all 6 subsets)

#Branded Monthly Sums by Category
overall_branded_sums = Master_data3.groupby(['final_category'], as_index=False)['BRAND_T_10', 'BRAND_T_09', 'BRAND_T_08','BRAND_T_07', 'BRAND_T_06', 'BRAND_T_05', 'BRAND_T_04', 'BRAND_T_03','BRAND_T_02', 'BRAND_T_01'].sum()
overall_branded_sums.to_clipboard()
# Market Monthly Sums by Category
overall_mkt_sums = Master_data3.groupby(['final_category'], as_index=False)['MKT_T_10', 'MKT_T_09','MKT_T_08', 'MKT_T_07', 'MKT_T_06', 'MKT_T_05', 'MKT_T_04', 'MKT_T_03','MKT_T_02', 'MKT_T_01'].sum()
overall_mkt_sums.to_clipboard()
# Counts of patients by payment type
overall_payment_counts = Master_data3[['payment_type','patient_id']].groupby(['payment_type'],as_index=False).nunique()
overall_payment_counts.to_clipboard()
Master_data3.patient_id.nunique()
Master_data3.columns

# Counts of patients by payment type only for patients who recieved Brand TRx in the post-period
payment_post_counts = Master_data3[Master_data3['MKT_T_4M_01']>0].groupby(['payment_type'],as_index=False)['patient_id'].nunique()
payment_post_counts.to_clipboard()

# Counts of patients by payment type only for patients who recieved Brand TRx in the post-period
age_buc_post_counts = Master_data3[Master_data3['MKT_T_4M_01']>0].groupby(['age_buc'],as_index=False)['patient_id'].nunique()
age_buc_post_counts.to_clipboard()

# Brand Monthly values by Age Bucket
age_buc_brand_fills = Master_data3.groupby(['age_buc'], as_index=False)['BRAND_T_10', 'BRAND_T_09', 'BRAND_T_08','BRAND_T_07', 'BRAND_T_06', 'BRAND_T_05', 'BRAND_T_04', 'BRAND_T_03','BRAND_T_02', 'BRAND_T_01'].sum()
age_buc_brand_fills.to_clipboard()
# Market Monthly values by Age Bucket
age_buc_mkt_fills = Master_data3.groupby(['age_buc'], as_index=False)['MKT_T_10', 'MKT_T_09','MKT_T_08', 'MKT_T_07', 'MKT_T_06', 'MKT_T_05', 'MKT_T_04', 'MKT_T_03','MKT_T_02', 'MKT_T_01'].sum()
age_buc_mkt_fills.to_clipboard()

# Xifaxan patient counts by Age Bucket
age_buc_brand_pats = Master_data3[Master_data3['BRAND_T_6M_02']>0].groupby(['age_buc'], as_index=False)['patient_id'].count()
age_buc_brand_pats.to_clipboard()
# Market patient counts by Age Bucket
age_buc_mkt_pats = Master_data3[Master_data3['MKT_T_6M_02']>0].groupby(['age_buc'], as_index=False)['patient_id'].count()
age_buc_mkt_pats.to_clipboard()
# Patient counts by Diagnosis Month
pats_by_dx_month = Master_data3.groupby(['dx_month'],as_index=False)['patient_id'].count()
pats_by_dx_month.to_clipboard()

# All Exposed patient counts by Age Bucket
age_buc_mkt_pats = Master_data3.groupby(['age_buc'], as_index=False)['patient_id'].nunique()
age_buc_mkt_pats.to_clipboard()

# All Exposed patient counts by Gender
gender_mkt_pats = Master_data3.groupby(['patient_gender'], as_index=False)['patient_id'].nunique()
gender_mkt_pats.to_clipboard()

# All Exposed patient counts by category
cat_mkt_pats = Master_data3.groupby(['pt_category_he_ibsd'], as_index=False)['patient_id'].nunique()
cat_mkt_pats.to_clipboard()

# All Exposed patient counts by final category
cat_mkt_pats = Master_data3.groupby(['final_category'], as_index=False)['patient_id'].nunique()
cat_mkt_pats.to_clipboard()

# All Exposed patients counts by refills
pat_refills = Master_data3.groupby(['patient_id'], as_index=False)['BRAND_T_4M_01','BRAND_N_4M_01'].sum()
pat_refills
pat_refills['Refills'] = pat_refills['BRAND_T_4M_01'] - pat_refills['BRAND_N_4M_01']

refills = pat_refills.groupby(['Refills'], as_index=False)['patient_id'].nunique()
refills.to_clipboard()

#%% HCP Data Creation 

mapping = pd.read_csv(r'D:\DrFirst\Output\test_hcp_mapping_file.csv')
mapping['ims_id']= mapping['ims_id'].astype(float)
mapping.shape # (13357, 2)
mapping.columns

hcp_deciles = pd.read_pickle(r'D:\DrFirst\LAAD_Data\HCP_Brand_Mkt_Deciles_v2.pkl')
hcp_deciles = hcp_deciles.fillna(0)
hcp_deciles.columns
hcp_deciles['ims_id'] = hcp_deciles['ims_id'].astype(float)

hcp_data = mapping.merge(hcp_deciles, on='ims_id', how='left')
hcp_data.shape # (13357, 18)
hcp_data.columns


Master_shortened = Master_data2[['patient_id','pt_category_he_ibsd','final_category', 'claim_type', 'payment_type','SPEC']]
Master_shortened['patient_id'] = Master_shortened['patient_id'].astype(float)

test_hcp_data = hcp_data.merge(Master_shortened, on='patient_id',how='left')
test_hcp_data.shape # (18024, 23)

# Test Only & Splitting by Indication
ibsd_test_hcps = test_hcp_data[(test_hcp_data['pt_category_he_ibsd']=='IBSD')]
he_test_hcps = test_hcp_data[(test_hcp_data['pt_category_he_ibsd']=='HE')]
other_test_hcps = test_hcp_data[(test_hcp_data['pt_category_he_ibsd']=='OTHER')]

test_hcp_data.columns
#%% HCP Summaries pt 1 (repeat for only 3 test subsets)

# Change input dataset in line 152 to get different results for each pt category
# Options : [ibsd_test_hcps, he_test_hcps, other_test_hcps]
test_hcp_data2 = other_test_hcps.copy()

# HCPs by specialty
hcps_by_spec = test_hcp_data2.groupby(['SPEC'], as_index=False)['ims_id'].count()
hcps_by_spec.to_clipboard()
# Number of HCPs within Test patient-count buckets
hcp_pat_counts = test_hcp_data2.groupby(['ims_id'], as_index=False)['patient_id'].count()
hcp_pat_counts=hcp_pat_counts.rename(columns={'patient_id':'pat_count'})
a=len(hcp_pat_counts[hcp_pat_counts['pat_count']==1])
b=len(hcp_pat_counts[hcp_pat_counts['pat_count']==2])
c=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=3)&(hcp_pat_counts['pat_count']<=20)])
d=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=21)&(hcp_pat_counts['pat_count']<=40)])
e=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=41)&(hcp_pat_counts['pat_count']<=60)])
f=len(hcp_pat_counts[(hcp_pat_counts['pat_count']>=61)])

pat_counts = pd.DataFrame([['1',a],['2',b], ['3-20',c],['21-40',d],['41-60',e],['61+',f]])
pat_counts.columns=['Patient Bucket','Number of HCPs']
pat_counts.to_clipboard()

# HCPs and Test Patients by Diagnosis Month
hcp_pat_months = test_hcp_data2.groupby(['dx_month'], as_index=False)['ims_id','patient_id'].count()
hcp_pat_months.to_clipboard()


#%% HCP Summaries pt 2 (No need to repeat)

# Count of HCPs by Brand Decile
ibsd_brand_decile = ibsd_test_hcps.groupby(['IBSD_brand_TRx_6M_decile'], as_index=False)['ims_id'].count()
ibsd_brand_decile.to_clipboard()
he_brand_decile = he_test_hcps.groupby(['HE_brand_TRx_6M_decile'], as_index=False)['ims_id'].count()
he_brand_decile.to_clipboard()
other_brand_decile = other_test_hcps.groupby(['OTHER_brand_TRx_6M_decile'], as_index=False)['ims_id'].count()
other_brand_decile.to_clipboard()

# Count of HCPs by Market Decile
ibsd_mkt_decile = ibsd_test_hcps.groupby(['IBSD_mkt_TRx_6M_decile'], as_index=False)['ims_id'].count()
ibsd_mkt_decile.to_clipboard()
he_mkt_decile = he_test_hcps.groupby(['HE_mkt_TRx_6M_decile'], as_index=False)['ims_id'].count()
he_mkt_decile.to_clipboard()
other_mkt_decile = other_test_hcps.groupby(['OTHER_mkt_TRx_6M_decile'], as_index=False)['ims_id'].count()
other_mkt_decile.to_clipboard()


#%% Tom's Attempt at Average TTF Summary (no need to repeat)

Master_data2['post_ttf_seg'] = np.where(Master_data2['post_nrx_avg_ttf']>60,">60",np.where(Master_data2['post_nrx_avg_ttf']<60,"<60","60"))

# Overall
post_ttf_pat_counts = Master_data2.groupby(['final_category','post_ttf_seg'],as_index=False)['patient_id'].count()
post_ttf_pat_counts.to_clipboard()

# Test Only
test_post_ttf_pat_counts = Master_data2[(Master_data2['T_C']=='T')].groupby(['final_category','post_ttf_seg'],as_index=False)['patient_id'].count()
test_post_ttf_pat_counts.to_clipboard()

#%% Average TTF

# Average time to fill, Will pick that up tomorrow

# Master_data2['pre_ov_ttf_calc'] = Master_data2['pre_ov_avg_ttf'] * Master_data2['pre_ov_n']
# Master_data2[['patient_id','pre_ov_ttf_calc', 'pre_ov_n', 'pre_ov_avg_ttf']].isna().sum()
# ttf_temp = Master_data2[['patient_id','pre_ov_ttf_calc', 'pre_ov_n']].groupby('patient_id').sum().reset_index()
# ttf_temp['pre_ov_ttf'] = ttf_temp['pre_ov_ttf_calc']/np.where(ttf_temp['pre_ov_n']==0,1,ttf_temp['pre_ov_n'])
# ttf_temp.isna().sum()
# ttf_temp['pre_ov_ttf_class'] = np.where(ttf_temp['pre_ov_ttf']<=60, "<=60", ">60")
# ttf_temp_agg = ttf_temp[['pre_ov_ttf_class', 'patient_id']].groupby('pre_ov_ttf_class').nunique().reset_index()
# ttf_temp_agg.to_clipboard()

#%%
Master_data3.columns

Master_data3[Master_data3['MKT_T_01']>0]['patient_id'].nunique()

# Counts of patients by payment type
overall_payment_counts = Master_data3[['payment_type','patient_id']].groupby(['payment_type'],as_index=False).nunique()
overall_payment_counts.to_clipboard()
Master_data3.patient_id.nunique()
Master_data3.columns

overall_payment_counts



